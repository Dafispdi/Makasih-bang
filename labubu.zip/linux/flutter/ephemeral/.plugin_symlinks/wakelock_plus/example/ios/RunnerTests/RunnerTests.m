//
//  RunnerTests.m
//  RunnerTests
//
//  Created by Diego Tori on 6/7/23.
//

@import XCTest;
@import integration_test;

INTEGRATION_TEST_IOS_RUNNER(RunnerTests)
