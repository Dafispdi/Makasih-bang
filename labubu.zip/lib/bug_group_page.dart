import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'dart:convert';
import 'dart:ui';
import 'constants.dart'; // Pastikan file constants.dart ada (berisi definisi warna primaryDark, accentPink, dll)

class BugGroupPage extends StatefulWidget {
  final String sessionKey;
  final String userId;
  final String role;
  
  const BugGroupPage({
    Key? key,
    required this.sessionKey,
    required this.userId,
    required this.role,
  }) : super(key: key);

  @override
  State<BugGroupPage> createState() => _BugGroupPageState();
}

class _BugGroupPageState extends State<BugGroupPage> with TickerProviderStateMixin {
  final urlController = TextEditingController();
  bool isLoading = false;
  bool isFetchingBugs = true;
  
  String? selectedBugId;
  List<Map<String, dynamic>> groupBugList = [];
  
  // Logic Global Sender
  int globalSenders = 0;
  bool checkingGlobal = true;
  
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // Video Controller
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    // Setup Animasi Pulse untuk tombol & banner
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.02).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _initializeVideoPlayer();
    _checkGlobalStatus(); // Cek status server global
    fetchGroupBugs(); // Ambil list bug dari backend (index.js)
  }

  // Cek apakah server Global (VPS) aktif
  Future<void> _checkGlobalStatus() async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/stats'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({"type": "stats"}),
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            globalSenders = data['activeConnections'] ?? 0;
            checkingGlobal = false;
          });
        }
      } else {
        if (mounted) setState(() => checkingGlobal = false);
      }
    } catch (e) {
      if (mounted) setState(() => checkingGlobal = false);
    }
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
          allowFullScreen: false,
          allowMuting: false,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      debugPrint("Video Error: $error");
      setState(() => _isVideoInitialized = false);
    });
  }

  // Fetch data bug dari endpoint backend yang baru
  Future<void> fetchGroupBugs() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/saturn/group-bugs"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          groupBugList = List<Map<String, dynamic>>.from(data);
          // Auto select item pertama jika ada
          if (groupBugList.isNotEmpty) {
            selectedBugId = groupBugList[0]['id'];
          }
          isFetchingBugs = false;
        });
      } else {
        setState(() => isFetchingBugs = false);
      }
    } catch (e) {
      debugPrint("Error fetching bugs: $e");
      setState(() => isFetchingBugs = false);
    }
  }

  Future<void> launchAttack() async {
    if (urlController.text.isEmpty || selectedBugId == null) {
       _showCyberAlert(
        false, 
        "INPUT ERROR", 
        {"ERROR": "Target Empty", "REASON": "Url Missing"}
      );
      return;
    }

    // Ambil detail bug yang dipilih untuk log
    final bugData = groupBugList.firstWhere(
      (element) => element['id'] == selectedBugId, 
      orElse: () => {'name': 'Unknown Protocol'}
    );
    
    setState(() => isLoading = true);

    try {
      final response = await http.post(
        Uri.parse("$baseUrl/api/saturn/group-kill"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "key": widget.sessionKey,
          "id": widget.userId,
          "url": urlController.text,
          "bugType": selectedBugId,
        }),
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(response.body);
      final bool isSuccess = data['success'] == true;
      final String target = data['target'] ?? "Group Unknown";

      // Data Log Terminal
      final Map<String, String> logDetails = {
        "PAYLOAD": bugData['name'],
        "TARGET": target.length > 15 ? "${target.substring(0, 15)}..." : target,
        "STATUS": isSuccess ? "DESTROYED" : "FAILED",
        "EXEC TIME": "${DateTime.now().hour}:${DateTime.now().minute}:${DateTime.now().second}",
      };

      if (mounted) {
        _showCyberAlert(
          isSuccess, 
          isSuccess ? "GROUP ELIMINATED" : "ATTACK FAILED",
          logDetails
        );
      }
      
      if (isSuccess) urlController.clear();

    } catch (e) {
      if (mounted) {
        _showCyberAlert(
          false, 
          "SERVER ERROR", 
          {"STATUS": "Disconnected", "REASON": "Timeout/Network"}
        );
      }
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _showCyberAlert(bool success, String title, Map<String, String> details) {
    if (!_isVideoInitialized) return; 

    showDialog(
      context: context,
      barrierDismissible: false, 
      barrierColor: Colors.black.withOpacity(0.85), 
      builder: (context) {
        return CyberVideoAlert(
          videoController: _videoController, 
          isSuccess: success,
          title: title,
          details: details,
          onClosed: () {},
        );
      },
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    urlController.dispose();
    if (_isVideoInitialized) {
      _videoController.dispose();
      _chewieController.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: SaturnXBackground(
      child: Stack(
        children: [
          // Background Aura Glow (Efek Cyberpunk)
          Positioned(
            top: -150,
            left: -50,
            child: ImageFiltered( 
              imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
              child: Container(
                width: 350, 
                height: 350, 
                decoration: BoxDecoration(
                  color: accentPink.withOpacity(0.05), 
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                _buildTopNav(),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10),
                        Center(child: _buildSenderStatus()),
                        const SizedBox(height: 15),
                        
                        _buildHeroBanner(),
                        const SizedBox(height: 30),
                        
                        _buildLabel("TARGET GROUP LINK"),
                        _buildCyberInput(),
                        const SizedBox(height: 25),
                        
                        _buildLabel("SELECT PAYLOAD ENGINE"),
                        
                        // --- UPDATED: Grid Payload (Pengganti Dropdown) ---
                        _buildPayloadGrid(),
                        
                        const SizedBox(height: 40),
                        
                        _buildMainExecuteButton(),
                        const SizedBox(height: 25),
                        
                        Center(child: _buildFooter()),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
       ), 
      ),
    );
  }

  // === WIDGETS SECTION ===

    Widget _buildPayloadGrid() {
    if (isFetchingBugs) {
      return Container(
        height: 100,
        alignment: Alignment.center,
        child: const CircularProgressIndicator(color: accentPink),
      );
    }

    if (groupBugList.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: cardDark.withOpacity(0.5),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.redAccent.withOpacity(0.3))
        ),
        child: const Center(
          child: Text("NO PAYLOADS AVAILABLE", style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono')),
        ),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, 
        crossAxisSpacing: 12, 
        mainAxisSpacing: 12, 
        childAspectRatio: 1.3, 
      ),
      itemCount: groupBugList.length,
      itemBuilder: (context, index) {
        final bug = groupBugList[index];
        final bool isSelected = selectedBugId == bug['id'];
        
        return GestureDetector(
          onTap: () {
            setState(() => selectedBugId = bug['id']);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isSelected 
                  ? accentPink.withOpacity(0.15) 
                  : cardDark.withOpacity(0.4),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isSelected ? accentPink : Colors.white10,
                width: isSelected ? 1.5 : 1,
              ),
              boxShadow: isSelected ? [
                BoxShadow(
                  color: accentPink.withOpacity(0.2),
                  blurRadius: 12,
                  spreadRadius: 1
                )
              ] : [],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // --- PERUBAHAN DISINI (DARI ICON KE TEXT EMOJI) ---
                Text(
                  bug['icon'] ?? '👾', // Ambil emoji dari backend
                  style: TextStyle(
                    fontSize: 32, // Ukuran Emoji
                    shadows: isSelected ? [
                      BoxShadow(
                        color: accentPink.withOpacity(0.8),
                        blurRadius: 20,
                        spreadRadius: 5,
                      )
                    ] : [],
                  ),
                ),
                // --------------------------------------------------
                
                const SizedBox(height: 10),
                Text(
                  bug['name'] ?? 'UNKNOWN',
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.white70,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    letterSpacing: 1
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Text(
                  bug['desc'] ?? '',
                  style: TextStyle(
                    color: isSelected ? Colors.white70 : Colors.white24,
                    fontSize: 9,
                    fontFamily: 'ShareTechMono'
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

    // TAMBAHKAN WIDGET INI
  Widget _buildSenderStatus() {
    // Logic: Hanya Owner yang bisa Global
    bool isOwner = widget.role.toLowerCase() == 'owner';
    bool useGlobal = isOwner && globalSenders > 0;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: useGlobal ? Colors.cyanAccent.withOpacity(0.5) : accentPink.withOpacity(0.5),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: useGlobal ? Colors.cyanAccent.withOpacity(0.1) : accentPink.withOpacity(0.1),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min, // Biar ukurannya pas konten
        children: [
          // Icon Berkedip (Opsional efek visual)
          Icon(
            useGlobal ? Icons.public : Icons.lock_outline,
            color: useGlobal ? Colors.cyanAccent : accentPink,
            size: 16,
          ),
          const SizedBox(width: 8),
          
          // Teks Status
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                useGlobal ? "SENDER MODE: GLOBAL" : "SENDER MODE: PRIVATE",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                  fontFamily: 'Orbitron', // Font scifi
                ),
              ),
              Text(
                useGlobal 
                    ? "Using Random Active Session ($globalSenders Online)" 
                    : "Using Your Connected Session",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.6),
                  fontSize: 8,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTopNav() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: Row(
        children: [
          IconButton(icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white70, size: 20), onPressed: () => Navigator.pop(context)),
          const Expanded(child: Text("SATURNX MODULE", textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Orbitron', color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 4))),
          const Icon(Icons.shield_outlined, color: Colors.greenAccent, size: 20),
        ],
      ),
    );
  }

  Widget _buildHeroBanner() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Container(
            padding: const EdgeInsets.all(1.5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20), 
              gradient: LinearGradient(colors: [accentPink, Colors.transparent, dangerRed])),
            child: Container(
              height: 140,
              decoration: BoxDecoration(
                color: Colors.black, 
                borderRadius: BorderRadius.circular(19), 
                image: const DecorationImage(image: AssetImage('assets/images/logo.jpg'), fit: BoxFit.cover, opacity: 0.25)),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("GROUP KILLER", style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 3)),
                    const SizedBox(height: 5),
                    Container(height: 1.5, width: 80, color: accentPink),
                    const SizedBox(height: 10),
                    Text("STATUS: READY TO LAUNCH", style: TextStyle(color: accentPink, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildLabel(String text) {
    return Padding(padding: const EdgeInsets.only(left: 4, bottom: 8), 
      child: Text(text, style: TextStyle(color: accentPink.withOpacity(0.8), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontFamily: 'Orbitron')));
  }

  Widget _buildCyberInput() {
    return Container(
      decoration: BoxDecoration(
        color: cardDark, 
        borderRadius: BorderRadius.circular(12), 
        border: Border.all(color: Colors.white10)),
      child: TextField(
        controller: urlController,
        style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
        decoration: InputDecoration(
          hintText: "https://chat.whatsapp.com/...",
          hintStyle: const TextStyle(color: Colors.white24, fontSize: 13),
          prefixIcon: Icon(Icons.gps_fixed, color: accentPink, size: 18),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(18),
        ),
      ),
    );
  }

  Widget _buildMainExecuteButton() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return GestureDetector(
          onTap: isLoading ? null : launchAttack,
          child: Transform.scale(
            scale: isLoading ? 1.0 : _pulseAnimation.value,
            child: Container(
              height: 65,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: dangerRed.withOpacity(0.4), blurRadius: 15)],
                gradient: LinearGradient(colors: [dangerRed, accentPink])
              ),
              child: Center(
                child: isLoading 
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.bolt, color: Colors.white),
                        SizedBox(width: 10),
                        Text("INITIALIZE ATTACK", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 2)),
                      ],
                    ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        const Text("CONNECTION ENCRYPTED (SATURNX-7.0)", style: TextStyle(color: Colors.white24, fontSize: 8, letterSpacing: 2, fontFamily: 'ShareTechMono')),
        const SizedBox(height: 5),
        Container(width: 40, height: 1, color: Colors.white10),
      ],
    );
  }
}

// ==========================================
// CYBER ALERT WIDGET (Popup Hasil Attack)
// ==========================================
class CyberVideoAlert extends StatelessWidget {
  final VideoPlayerController videoController;
  final bool isSuccess;
  final String title;
  final Map<String, String> details; 
  final VoidCallback onClosed;

  const CyberVideoAlert({
    Key? key,
    required this.videoController,
    required this.isSuccess,
    required this.title,
    required this.details,
    required this.onClosed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colorTheme = isSuccess ? const Color(0xFF10B981) : const Color(0xFFFF2D55);
    final icon = isSuccess ? Icons.check_circle_outline : Icons.warning_amber_rounded;

    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 400),
        tween: Tween<double>(begin: 0.8, end: 1.0),
        curve: Curves.elasticOut,
        builder: (context, double scale, child) {
          return Transform.scale(
            scale: scale,
            child: child,
          );
        },
        child: Container(
          width: 340,
          constraints: const BoxConstraints(minHeight: 420),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: colorTheme.withOpacity(0.8), width: 2),
            boxShadow: [
              BoxShadow(
                color: colorTheme.withOpacity(0.4),
                blurRadius: 30,
                spreadRadius: 2,
              )
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              children: [
                // Video Background
                Positioned.fill(
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: videoController.value.size.width,
                      height: videoController.value.size.height,
                      child: VideoPlayer(videoController),
                    ),
                  ),
                ),
                // Overlay Gradient
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.8),
                          colorTheme.withOpacity(0.3), 
                        ],
                      ),
                    ),
                  ),
                ),
                // Blur Effect
                Positioned.fill(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
                    child: Container(color: Colors.transparent),
                  ),
                ),
                // Content
                Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min, 
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(icon, color: colorTheme, size: 70),
                      const SizedBox(height: 15),
                      Text(
                        title,
                        style: TextStyle(
                          color: colorTheme,
                          fontFamily: 'Orbitron',
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          shadows: [Shadow(color: colorTheme, blurRadius: 15)],
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: colorTheme.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "// EXECUTION LOG",
                              style: TextStyle(
                                color: colorTheme.withOpacity(0.7),
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                letterSpacing: 1.5,
                              ),
                            ),
                            const Divider(color: Colors.white24, height: 10),
                            ...details.entries.map((entry) {
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      entry.key.toUpperCase(),
                                      style: const TextStyle(
                                        color: Colors.white60,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 12,
                                      ),
                                    ),
                                    Expanded(
                                      child: Text(
                                        entry.value,
                                        textAlign: TextAlign.right,
                                        style: TextStyle(
                                          color: colorTheme,
                                          fontFamily: 'ShareTechMono',
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 25),
                      SizedBox(
                        width: double.infinity,
                        height: 45,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                            onClosed();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: colorTheme.withOpacity(0.8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 10,
                            shadowColor: colorTheme.withOpacity(0.5),
                          ),
                          child: const Text(
                            "ACKNOWLEDGE",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                              fontFamily: 'Orbitron'
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
