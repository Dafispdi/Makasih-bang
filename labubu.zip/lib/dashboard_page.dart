import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'bug_sender.dart';
import 'package:http/http.dart' as http;
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'public_chat_page.dart';
import 'constants.dart';
import 'notification_page.dart';
import 'broadcast_creator_page.dart';
import 'custom_attack_page.dart';
import 'update_page.dart'; // Import halaman baru tadi
import 'dart:async'; // WAJIB: Untuk Timer
import 'notification_service.dart'; // WAJIB: Untuk memunculkan notif di atas layar
import 'dart:ui'; 

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  int globalSenders = 0; 
  bool _hasUnreadNotifs = false; 
  late AnimationController _controller;
  late AnimationController _fadeController;
  late Animation<double> _animation;
  late Animation<double> _fadeAnimation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";
  
  Timer? _notificationTimer;
  int _selectedTabIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  Widget _buildGlobalActiveButton() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.cyan.shade900, Colors.cyanAccent.shade700],
        ),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.cyanAccent.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.bolt, color: Colors.white, size: 20),
          const SizedBox(width: 10),
          Column(
            children: const [
              Text(
                "GLOBAL SENDER ACTIVE",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              Text(
                "High Speed Node (Auto-Connect)",
                style: TextStyle(color: Colors.white70, fontSize: 10),
              )
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildManualSenderButton() {
    return ElevatedButton.icon(
      icon: Icon(FontAwesomeIcons.whatsapp, color: primaryWhite, size: 18),
      label: Text(
        (role.toLowerCase() == 'vip' || role.toLowerCase() == 'owner') 
            ? "MANAGE PRIVATE SENDER" 
            : "MANAGE BUG SENDER",
        style: TextStyle(
          color: primaryWhite,
          fontSize: 14,
          fontWeight: FontWeight.bold,
          fontFamily: 'Orbitron',
          letterSpacing: 0.5,
        ),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFFB027F6),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: const Color(0xFFB027F6).withOpacity(0.5)),
        ),
        elevation: 4,
        shadowColor: const Color(0xFFB027F6).withOpacity(0.5),
      ),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BugSenderPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            ),
          ),
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _controller.forward();
    _fadeController.forward();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();

    // 1. Cek notif saat pertama buka
    _checkUnreadNotifications(); 

    // 2. Pasang Timer untuk cek ulang setiap 10 detik (Real-time Polling)
    _notificationTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (mounted) {
        _checkUnreadNotifications();
      }
    });
    
      WidgetsBinding.instance.addPostFrameCallback((_) {
      _showThanksToOverlay();
    });
  }
  
  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  // --- LOGIC AUTO UPDATE ---
  Future<void> _checkForUpdate({bool showPage = false}) async {
    try {
      // Ambil versi aplikasi saat ini
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      String currentVersion = packageInfo.version;

      // Request ke Server
      final response = await http.get(Uri.parse('$baseUrl/api/update-check'));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        // 1. Cek apakah ada update di server?
        if (data['success'] != true) {
            if (showPage) {
                // Muncul jika user klik tombol cek manual tapi server belum ada update
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Belum ada update tersedia dari server."))
                );
            }
            return;
        }

        String latestVersion = data['latestVersion'];

        // 2. Jika user klik tombol menu "Check Update" (Manual)
        if (showPage) {
           // Langsung buka halaman download biar user lihat infonya
           Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => UpdatePage(updateData: data)),
          );
          return;
        }

        // 3. Jika Cek Otomatis (Saat baru buka aplikasi)
        // Bandingkan versi sekarang vs versi baru
        if (latestVersion != currentVersion) {
          _showCustomUpdatePopup(data, currentVersion);
        } 
      }
    } catch (e) {
      print("Update Error: $e");
      if (showPage) {
         ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Gagal cek update: $e"))
         );
      }
    }
  }

  // POPUP STYLE PICT 2
  void _showCustomUpdatePopup(Map<String, dynamic> data, String currentVer) {
    String rawLogs = data['changeLog'] ?? '';
    List<String> features = rawLogs.split('|'); // Split changeLog

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: accentPink,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Container Utama
            Container(
              margin: const EdgeInsets.only(top: 40), // Ruang buat icon nongol
              padding: const EdgeInsets.only(top: 50, left: 20, right: 20, bottom: 20),
              decoration: BoxDecoration(
                color: const Color(0xFF0F172A),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentPink.withOpacity(0.5)),
                boxShadow: [BoxShadow(color: Colors.black45, blurRadius: 20)],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text("Update Tersedia!", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  Text("Versi ${data['latestVersion']} siap diunduh", style: const TextStyle(color: Colors.white70)),
                  Text("Versi Anda: $currentVer", style: const TextStyle(color: Colors.white38, fontSize: 12)),
                  const SizedBox(height: 20),
                  
                  // List Fitur (Bullet Points)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(10)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Fitur baru:", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        ...features.map((f) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            children: [
                              const Icon(Icons.check, color: Colors.green, size: 14),
                              const SizedBox(width: 5),
                              Expanded(child: Text(f, style: const TextStyle(color: Colors.white60, fontSize: 11))),
                            ],
                          ),
                        )).toList().take(5), // Ambil max 5 baris biar ga kepanjangan
                      ],
                    ),
                  ),

                  const SizedBox(height: 25),

                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("Nanti", style: TextStyle(color: Colors.white54)),
                        ),
                      ),
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.cyan,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          ),
                          onPressed: () {
                             Navigator.pop(context);
                             // Buka Halaman Full Detail
                             Navigator.push(context, MaterialPageRoute(builder: (_) => UpdatePage(updateData: data)));
                          },
                          child: const Text("Update Sekarang", style: TextStyle(color: Colors.white)),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            
            // Icon Bulet di Atas (Logo Refresh)
            Positioned(
              top: 0,
              child: Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.cyan,
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF0F172A), width: 5),
                  boxShadow: [BoxShadow(color: Colors.cyan.withOpacity(0.4), blurRadius: 20)]
                ),
                child: const Icon(Icons.history, color: Colors.white, size: 40),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
    void _connectToWebSocket() async {
    try {
      // 1. Validasi HTTP (Tetap diperlukan untuk keamanan awal)
      final validateResponse = await http.post(
        Uri.parse('$baseUrl/validate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "type": "validate",
          "key": sessionKey,
          "androidId": androidId,
        }),
      );

      // Jika validasi gagal, handle logout
      if (validateResponse.statusCode == 200) {
        final validateData = jsonDecode(validateResponse.body);
        if (validateData['type'] == 'myInfo' && validateData['valid'] == false) {
          _handleInvalidSession("Session Invalid.");
          return;
        }
      }

      // 2. KONEKSI WEBSOCKET (INI YANG BARU)
      // Ganti 'http' atau 'https' menjadi 'ws' atau 'wss'
      String wsUrl = baseUrl.replaceFirst("http", "ws"); 
      
      // Inisialisasi channel
      channel = WebSocketChannel.connect(Uri.parse(wsUrl));

      // Kirim pesan Auth ke Server
      channel.sink.add(jsonEncode({
        "type": "auth",
        "key": sessionKey,
      }));

      // 3. LISTEN DATA STREAM (Mendengarkan data real-time dari server)
      channel.stream.listen((message) {
        try {
          final data = jsonDecode(message);
          
          // Tangkap Update Stats Real-time
          if (data['type'] == 'realtimeStats') {
             if (mounted) {
               setState(() {
                 onlineUsers = data['onlineUsers'] ?? 0;
                 activeConnections = data['activeConnections'] ?? 0;
                 globalSenders = data['activeConnections'] ?? 0;
               });
             }
          }
          // Handle chat atau notif lain jika ada...
        } catch (e) {
          print("WS Parse Error: $e");
        }
      }, onDone: () {
        print("WS Disconnected");
      }, onError: (error) {
        print("WS Error: $error");
      });

    } catch (error) {
      print('Connection Error: $error');
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cardDarker,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("⚠️ Session Expired", style: TextStyle(color: accentPink, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: accentGrey)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: accentPink, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _onTabTapped(int index) {
    setState(() {
      _selectedTabIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = ToolsPage(
            sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      } else if (index == 3) {
        _selectedPage = PublicChatPage(
          username: widget.username,
          role: widget.role,
        );
      }
    });
  }

  void _onDrawerItemSelected(int index) {
    setState(() {
      if (index == 3) _selectedPage = NikCheckerPage();
      else if (index == 4) _selectedPage = ChangePasswordPage(username: username, sessionKey: sessionKey);
      else if (index == 5) _selectedPage = SellerPage(
          keyToken: sessionKey, 
          userRole: role // FIX: Pass role ke sini
      );
      else if (index == 6) _selectedPage = AdminPage(sessionKey: sessionKey);
    });
  }

    Widget _buildNewsPage() {
    bool isOwner = role.toLowerCase() == 'owner';
    bool useGlobalSender = isOwner && globalSenders > 0;

    return SingleChildScrollView(
      padding: EdgeInsets.only(left: 16, right: 16, top: MediaQuery.of(context).padding.top + kToolbarHeight + 16, bottom: 120), 
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeaderSection(),
          const SizedBox(height: 24),
          _buildAccountInfo(),
          const SizedBox(height: 12),
          if (useGlobalSender) ...[
             _buildGlobalActiveButton(),
             const SizedBox(height: 12), 
          ],
          SizedBox(width: double.infinity, child: _buildManualSenderButton()),
          _buildCustomAttackButton(),
        ],
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.2)),
        gradient: LinearGradient(
          colors: [primaryPink.withOpacity(0.8), accentPink.withOpacity(0.6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: primaryPink.withOpacity(0.3), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.auto_awesome, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Welcome back,", style: TextStyle(color: Colors.white70, fontSize: 14)),
                    Text(
                      username,
                      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _buildQuickStat(icon: Icons.people_outline, label: "Online Users", value: "$onlineUsers"),
              const SizedBox(width: 16),
              _buildQuickStat(icon: Icons.electrical_services, label: "Connections", value: "$activeConnections"),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStat({required IconData icon, required String label, required String value}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.black.withOpacity(0.2), borderRadius: BorderRadius.circular(16)),
        child: Row(
          children: [
            Icon(icon, color: cyanIridescent, size: 24),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)),
                  Text(value, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountInfo() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.dashboard_customize, color: cyanIridescent),
              const SizedBox(width: 8),
              const Text("Quick Actions", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 16),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.5,
            children: [
              _buildActionCard(icon: Icons.system_update, label: "Check Update", onTap: () => _checkForUpdate(showPage: true)),
              if (role == "reseller" || role == "owner" || role == "admin")
                _buildActionCard(
                  icon: Icons.store,
                  label: "Seller Page",
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SellerPage(keyToken: sessionKey, userRole: role))), 
                ),
              if (role == "owner")
                _buildActionCard(icon: Icons.admin_panel_settings, label: "Admin Panel", onTap: () => _onDrawerItemSelected(6)),
               if (role == "owner")
                _buildActionCard(
                  icon: Icons.campaign, 
                  label: "Broadcast Setting",
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => BroadcastCreatorPage(sessionKey: sessionKey))),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // GANTI SEMUA CONTAINER STATISTIK/INFO DENGAN GlassCard
  Widget _buildStatCard({required IconData icon, required String title, required String value, required Color color, bool fullWidth = false}) {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      margin: fullWidth ? null : EdgeInsets.zero,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12)),
                Text(value, style: TextStyle(color: color, fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  // ==========================================
  //  FITUR: THANKS TO / CREDIT SYSTEM
  // ==========================================

  // 1. Helper Buka Link
  Future<void> _launchURL(String? url) async {
    if (url == null || url.isEmpty) return;
    final Uri uri = Uri.parse(url);
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw 'Could not launch $url';
      }
    } catch (e) {
      print("Error launching URL: $e");
    }
  }

  // 2. Logic Ambil Data & Tampilkan Overlay
  Future<void> _showThanksToOverlay() async {
    try {
      // Panggil API Backend
      final response = await http.get(Uri.parse('$baseUrl/api/thanks-to'));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        if (!mounted) return;

        // Tampilkan Dialog Animasi
        showGeneralDialog(
          context: context,
          barrierDismissible: false, // User wajib klik tombol "ENTER SYSTEM"
          barrierLabel: "Credits",
          barrierColor: Colors.black.withOpacity(0.85),
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (context, anim1, anim2) {
            return _buildThanksToContent(data);
          },
          transitionBuilder: (context, anim1, anim2, child) {
            // Animasi Elastic Pop-up
            return Transform.scale(
              scale: CurvedAnimation(parent: anim1, curve: Curves.elasticOut).value,
              child: FadeTransition(opacity: anim1, child: child),
            );
          },
        );
      }
    } catch (e) {
      print("Gagal load credits: $e");
    }
  }

  // 3. UI: Popup Biodata Detail (Saat Nama Diklik)
  void _showContributorProfile(Map<String, dynamic> user) {
    // Mapping Warna dari String Backend ke Color Flutter
    Color roleColor = Colors.white;
    String colorCode = user['color'] ?? 'white';
    if (colorCode == 'purple') roleColor = const Color(0xFFB027F6);
    if (colorCode == 'blue') roleColor = Colors.cyanAccent;
    if (colorCode == 'green') roleColor = const Color(0xFF00FF9D);
    if (colorCode == 'pink') roleColor = const Color(0xFFFF2E63);

    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF0F0518), // Background Gelap Pekat
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: roleColor, width: 2), // Border Warna Role
            boxShadow: [
              BoxShadow(color: roleColor.withOpacity(0.4), blurRadius: 25, spreadRadius: 2)
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Avatar Circle
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: roleColor.withOpacity(0.1),
                  border: Border.all(color: roleColor.withOpacity(0.5), width: 2),
                ),
                child: Icon(Icons.person_outline, size: 50, color: roleColor),
              ),
              const SizedBox(height: 15),

              // Nama & Role
              Text(
                user['name'] ?? "Unknown",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [Shadow(color: Colors.white54, blurRadius: 10)],
                ),
              ),
              const SizedBox(height: 5),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: roleColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  (user['role'] ?? "MEMBER").toUpperCase(),
                  style: TextStyle(
                    color: roleColor,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Bio Box
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white10),
                ),
                child: Text(
                  user['bio'] ?? "No data available in Server.",
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontFamily: 'ShareTechMono',
                    color: Colors.white70,
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.white24),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text("CLOSE", style: TextStyle(color: Colors.white70)),
                    ),
                  ),
                  if (user['social_url'] != null && user['social_url'].toString().isNotEmpty) ...[
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: roleColor,
                          foregroundColor: Colors.black, // Text Hitam biar kontras
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        onPressed: () => _launchURL(user['social_url']),
                        icon: const Icon(Icons.open_in_new, size: 16),
                        label: Text(
                          "OPEN ${user['social_label'] ?? 'LINK'}", 
                          style: const TextStyle(fontWeight: FontWeight.bold)
                        ),
                      ),
                    ),
                  ],
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  // 4. UI: Tampilan List Kaca (Overlay Utama)
  Widget _buildThanksToContent(Map<String, dynamic> data) {
    List contributors = data['contributors'] ?? [];

    return Center(
      child: Material(
        color: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(25),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10), // Efek Kaca Blur
            child: Container(
              width: MediaQuery.of(context).size.width * 0.85,
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.75, // Max tinggi 75% layar
              ),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                // Warna Background Kaca Gelap
                color: const Color(0xFF05000A).withOpacity(0.7), 
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: accentPink.withOpacity(0.5), width: 1),
                boxShadow: [
                  BoxShadow(color: accentPink.withOpacity(0.15), blurRadius: 40, spreadRadius: 1)
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // --- HEADER ---
                  const Icon(Icons.groups_3, color: Colors.white, size: 40),
                  const SizedBox(height: 10),
                  Text(
                    data['title'] ?? "CREDITS",
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 3,
                      shadows: [Shadow(color: accentPink, blurRadius: 15)],
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    data['description'] ?? "Loading system data...",
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'ShareTechMono'),
                  ),
                  const SizedBox(height: 20),
                  const Divider(color: Colors.white12, thickness: 1),
                  const SizedBox(height: 10),

                  // --- LIST CONTRIBUTORS (SCROLLABLE) ---
                  Flexible(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        children: contributors.map((user) {
                          // Tentukan warna berdasarkan data backend
                          Color roleColor = Colors.grey;
                          String colorCode = user['color'] ?? 'white';
                          if (colorCode == 'purple') roleColor = const Color(0xFFB027F6);
                          if (colorCode == 'blue') roleColor = Colors.cyanAccent;
                          if (colorCode == 'green') roleColor = const Color(0xFF00FF9D);
                          if (colorCode == 'pink') roleColor = const Color(0xFFFF2E63);

                          return Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.03),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.white10),
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius: BorderRadius.circular(12),
                                splashColor: roleColor.withOpacity(0.2),
                                onTap: () => _showContributorProfile(user), // KLIK DISINI
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                  child: Row(
                                    children: [
                                      // Garis Indikator Warna Kiri
                                      Container(
                                        width: 3,
                                        height: 35,
                                        decoration: BoxDecoration(
                                          color: roleColor,
                                          borderRadius: BorderRadius.circular(2),
                                          boxShadow: [BoxShadow(color: roleColor, blurRadius: 6)]
                                        ),
                                      ),
                                      const SizedBox(width: 16),
                                      
                                      // Nama & Tap Hint
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              user['name'],
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15,
                                                fontFamily: 'Orbitron'
                                              ),
                                            ),
                                            const Text(
                                              "Tap to view bio >",
                                              style: TextStyle(
                                                color: Colors.white30,
                                                fontSize: 10,
                                                fontStyle: FontStyle.italic
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      // Role Badge Kecil
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: roleColor.withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(6),
                                          border: Border.all(color: roleColor.withOpacity(0.3)),
                                        ),
                                        child: Text(
                                          user['role'],
                                          style: TextStyle(
                                            color: roleColor,
                                            fontSize: 10,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // --- TOMBOL MASUK ---
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accentPink,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 10,
                        shadowColor: accentPink.withOpacity(0.6),
                      ),
                      onPressed: () => Navigator.pop(context), // Tutup Overlay
                      child: const Text(
                        "CONTINUE TO SYSTEM",
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

    Widget _buildCustomAttackButton() {
    bool isLocked = role.toLowerCase() == 'member';

    return Container(
      margin: const EdgeInsets.only(top: 16),
      width: double.infinity,
      child: OutlinedButton.icon(
        icon: Icon(
          isLocked ? Icons.lock : Icons.build_circle, 
          color: isLocked ? Colors.grey : Colors.purpleAccent
        ),
        label: Text(
          isLocked ? "CUSTOM PAYLOAD (LOCKED)" : "CUSTOM PAYLOAD", 
          style: TextStyle(
            color: isLocked ? Colors.grey : Colors.purpleAccent, 
            fontFamily: 'Orbitron', 
            fontWeight: FontWeight.bold
          )
        ),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: isLocked ? Colors.grey : Colors.purpleAccent),
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
        ),
        onPressed: () {
          if (isLocked) {
             ScaffoldMessenger.of(context).showSnackBar(
               const SnackBar(content: Text("Upgrade to Hig role to unlock this feature! You need to upgrade role? contact @Kyxsancs or Contact seller Trusted"))
             );
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CustomAttackPage(
                  sessionKey: sessionKey,
                  username: username,
                ),
              ),
            );
          }
        },
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardDarker,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accentPink.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: accentPink, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner":
        return Colors.red;
      case "vip":
        return accentPink;
      case "reseller":
        return Colors.green;
      case "premium":
        return Colors.orange;
      default:
        return lightPink;
    }
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: cardDarker,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF5D1285), Color(0xFFB027F6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "SaturnX System",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                _buildDrawerInfo("User:", username),
                _buildDrawerInfo("Role:", role),
                _buildDrawerInfo("Expired:", expiredDate),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (role == "reseller" || role == "owner" || role == "admin")
            _buildDrawerItem(
              icon: Icons.store,
              label: "Seller Page",
              onTap: () {
                Navigator.pop(context);
                _onDrawerItemSelected(5);
              },
            ),
          if (role == "owner")
            _buildDrawerItem(
              icon: Icons.admin_panel_settings,
              label: "Admin Page",
              onTap: () {
                Navigator.pop(context);
                _onDrawerItemSelected(6);
              },
            ),
          const Divider(color: Colors.white24),
          _buildDrawerItem(
            icon: Icons.logout,
            label: "Logout",
            onTap: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: accentPink),
      title: Text(
        label,
        style: const TextStyle(color: Colors.white),
      ),
      onTap: onTap,
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: cardDarker,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: accentPink,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "Account Information",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 24),
            _infoCard(FontAwesomeIcons.user, "Username", username),
            _infoCard(FontAwesomeIcons.calendar, "Expired", expiredDate),
            _infoCard(FontAwesomeIcons.shieldAlt, "Role", role),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.lock_reset, color: Colors.white),
                    label: const Text("Change Password"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentPink,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.logout, color: Colors.white),
                    label: const Text("Logout"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                            (route) => false,
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  // SAYA JUGA MENGHAPUS _buildMiniPlayer DISINI

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentPink.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: accentPink.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: accentPink),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _checkUnreadNotifications() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/api/notifications'));
      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        
        if (data.isNotEmpty) {
          final latestNotif = data[0];
          final String latestId = latestNotif['id'].toString();
          
          final prefs = await SharedPreferences.getInstance();
          final String? lastSeenId = prefs.getString('last_seen_notif_id');
          final String? lastPopupId = prefs.getString('last_popup_notif_id'); // Key khusus popup

          // Logic 1: Titik Merah (Red Dot)
          if (latestId != lastSeenId) {
            if (mounted) setState(() => _hasUnreadNotifs = true);
          }

          // Logic 2: Notifikasi Sistem (Muncul di Bar Atas HP)
          if (latestId != lastPopupId) {
            // Simpan ID biar gak muncul terus menerus
            await prefs.setString('last_popup_notif_id', latestId);
            
            // Panggil Service Notifikasi
            NotificationService.showNotification(
              id: 0, 
              title: latestNotif['title'] ?? 'New Message',
              body: latestNotif['message'] ?? 'Check your dashboard.',
              type: latestNotif['type'] ?? 'info'
            );
          }
        }
      }
    } catch (e) {
      print("Gagal cek Informasi terbaru: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true, // Biar background nembus AppBar
      extendBody: true, // Biar background nembus BottomNav
      backgroundColor: Colors.transparent,
      
      appBar: AppBar(
        title: const Text(
          "SaturnX System",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: Colors.black.withOpacity(0.2),
        flexibleSpace: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(color: Colors.transparent),
          ),
        ),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_outlined, color: Colors.white),
                onPressed: () async {
                  await Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (_) => const NotificationPage())
                  );
                  if (mounted) setState(() => _hasUnreadNotifs = false);
                },
              ),
              if (_hasUnreadNotifs)
                Positioned(
                  right: 12,
                  top: 12,
                  child: Container(
                    padding: const EdgeInsets.all(1),
                    decoration: BoxDecoration(
                      color: dangerRed,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: Colors.white, width: 1), 
                    ),
                    constraints: const BoxConstraints(minWidth: 10, minHeight: 10),
                  ),
                )
            ],
          ),
          IconButton(
            icon: const Icon(Icons.account_circle, color: Colors.white),
            onPressed: _showAccountMenu,
          ),
        ],
      ),

      drawer: _buildDrawer(),

      // BUNGKUS DENGAN LEMBAYUNG BACKGROUND
      body: SaturnXBackground(
        child: FadeTransition(opacity: _animation, child: _selectedPage),
      ),

      // BOTTOM NAVBAR KACA
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.1), width: 1)),
        ),
        child: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: BottomNavigationBar(
              backgroundColor: Colors.white.withOpacity(0.05),
              selectedItemColor: cyanIridescent,
              unselectedItemColor: Colors.white54,
              currentIndex: _selectedTabIndex,
              onTap: _onTabTapped,
              elevation: 0,
              type: BottomNavigationBarType.fixed,
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: "Home"),
                BottomNavigationBarItem(icon: Icon(Icons.message_outlined), activeIcon: Icon(Icons.message), label: "WhatsApp"),
                BottomNavigationBarItem(icon: Icon(Icons.build_outlined), activeIcon: Icon(Icons.build), label: "Tools"),
                BottomNavigationBarItem(icon: Icon(Icons.forum_outlined), activeIcon: Icon(Icons.forum), label: "Public Chat"),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
    @override
  void dispose() {
    _notificationTimer?.cancel();
    _controller.dispose();
    _fadeController.dispose();
    
    // Cek dulu apakah channel sudah di-inisialisasi sebelum ditutup
    try {
      channel.sink.close(status.goingAway);
    } catch (e) {
      // Channel belum connect, biarkan saja
    }
    
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
void initState() {
  super.initState();
  if (_isVideo(widget.url)) {
    _controller = VideoPlayerController.networkUrl(
      Uri.parse(widget.url),
      // PERBAIKAN: Pastikan videoPlayerOptions ada SEBELUM kurung tutup ')'
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true), 
    )..initialize().then((_) {
        setState(() {});
        _controller?.setLooping(true);
        _controller?.setVolume(0.0);
        _controller?.play();
      });
  }
}

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFFF63B82),
          ),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.grey.shade800,
          child: const Icon(Icons.error, color: Color(0xFFF63B82)),
        ),
      );
    }
  }
}
