import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'constants.dart'; 

class CustomAttackPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const CustomAttackPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<CustomAttackPage> createState() => _CustomAttackPageState();
}

class _CustomAttackPageState extends State<CustomAttackPage> {
  final TextEditingController _targetController = TextEditingController();
  
  // Data
  List<dynamic> mySenders = [];
  String? selectedSender;
  List<dynamic> availablePayloads = []; 
  List<Map<String, dynamic>> attackSequence = [];
  
  // Loading States
  bool isLoading = false;
  bool isFetchingData = true;

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    await Future.wait([
      _fetchMySenders(),
      _fetchPayloads(),
    ]);
    if (mounted) {
      setState(() => isFetchingData = false);
    }
  }

  Future<void> _fetchPayloads() async {
    try {
      final res = await http.get(Uri.parse("$baseUrl/api/payloads"));
      final data = jsonDecode(res.body);
      
      if (data['success'] == true) {
        setState(() {
          availablePayloads = data['data'];
        });
      }
    } catch (e) {
      debugPrint("Gagal load payload: $e");
    }
  }

  Future<void> _fetchMySenders() async {
    try {
      final res = await http.get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"));
      final data = jsonDecode(res.body);
      
      if (data['valid'] == true) {
        setState(() {
          mySenders = data['connections'];
          if (mySenders.isNotEmpty) {
            // Kalau sender sebelumnya terpilih masih ada di list baru, pertahankan
            if (selectedSender == null || !mySenders.any((s) => s['sessionName'] == selectedSender)) {
               selectedSender = mySenders[0]['sessionName'];
            }
          } else {
            selectedSender = null;
          }
        });
      }
    } catch (e) {
       debugPrint("Gagal load sender: $e");
    }
  }

  // --- LOGIKA UI ITEM (ICON vs EMOJI) ---
  Widget _buildIconOrEmoji(String iconStr) {
    switch (iconStr) {
      case 'apple': return const Icon(Icons.apple, color: Colors.purpleAccent);
      case 'android': return const Icon(Icons.android, color: Colors.greenAccent);
      case 'settings': return const Icon(Icons.settings_system_daydream, color: Colors.blueAccent);
      case 'timer': return const Icon(Icons.timer_off, color: Colors.orangeAccent);
      case 'file': return const Icon(Icons.description, color: Colors.tealAccent);
      case 'emoji': return const Icon(Icons.emoji_emotions, color: Colors.yellowAccent);
      case 'call': return const Icon(Icons.add_call, color: Colors.redAccent);
      case 'bug': return const Icon(Icons.bug_report, color: Colors.white);
      default: return Text(iconStr, style: const TextStyle(fontSize: 24));
    }
  }

  void _addToSequence(dynamic payload, int count, int delayMs) {
    setState(() {
      attackSequence.add({
        "id": payload['id'],
        "name": payload['name'],
        "count": count,
        "delay": delayMs, // Tambahkan delay ke data
        "icon_raw": payload['icon']
      });
    });
    Navigator.pop(context);
  }

  Future<void> _executeAttack() async {
    if (_targetController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Target Number Required!")));
      return;
    }
    if (attackSequence.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please add at least 1 payload!")));
      return;
    }
    if (selectedSender == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("No Sender Selected! Go to Manage Sender to pair.")));
      return;
    }

    setState(() => isLoading = true);

    try {
      List<Map<String, dynamic>> backendSequence = attackSequence.map((e) => {
        "id": e['id'],
        "count": e['count'],
        "delay": e['delay'] ?? 1000 // Kirim delay ke backend
      }).toList();

      final res = await http.post(
        Uri.parse("$baseUrl/api/custom-attack"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "key": widget.sessionKey,
          "target": _targetController.text,
          "senderNumber": selectedSender,
          "sequence": backendSequence
        }),
      );

      final data = jsonDecode(res.body);
      
      if (mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: const Color(0xFF1A052E),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: Text(data['success'] ? "ATTACK LAUNCHED" : "FAILED", style: TextStyle(color: data['success'] ? Colors.green : Colors.red, fontFamily: 'Orbitron')),
            content: Text(data['message'] ?? "Unknown Error", style: const TextStyle(color: Colors.white70)),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("OK"))
            ],
          )
        );
      }

    } catch (e) {
       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  // --- UI: BOTTOM SHEET SELECTOR ---
  void _showPayloadSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0F021D),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const Text("Select Payload", style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
              const SizedBox(height: 15),
              Expanded(
                child: availablePayloads.isEmpty 
                ? const Center(child: Text("No Payloads Loaded", style: TextStyle(color: Colors.white54)))
                : ListView.separated(
                  separatorBuilder: (context, index) => Divider(color: Colors.white.withOpacity(0.1)),
                  itemCount: availablePayloads.length,
                  itemBuilder: (ctx, i) {
                    final item = availablePayloads[i];
                    return ListTile(
                      leading: _buildIconOrEmoji(item['icon']), 
                      title: Text(item['name'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      trailing: const Icon(Icons.add_circle, color: Colors.purpleAccent),
                      onTap: () {
                        _showCountDialog(item);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // --- DIALOG BARU DENGAN DELAY SLIDER ---
  void _showCountDialog(dynamic item) {
     Navigator.pop(context); 
     int count = 5; 
     int delay = 1000; // Default 1 detik

     showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1A052E),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: Text(item['name'], style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // SLIDER JUMLAH
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Jumlah Loop:", style: TextStyle(color: Colors.white70)),
                      Text("$count", style: const TextStyle(color: Colors.purpleAccent, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  Slider(
                    value: count.toDouble(),
                    min: 1,
                    max: 50,
                    activeColor: Colors.purpleAccent,
                    inactiveColor: Colors.white10,
                    onChanged: (val) {
                      setDialogState(() => count = val.toInt());
                    },
                  ),
                  const SizedBox(height: 16),

                  // SLIDER DELAY (NEW!)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Set Delay:", style: TextStyle(color: Colors.white70)),
                      Text("${delay}ms", style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  Slider(
                    value: delay.toDouble(),
                    min: 100,
                    max: 5000,
                    divisions: 49, // Biar stepnya per 100ms
                    activeColor: Colors.cyanAccent,
                    inactiveColor: Colors.white10,
                    onChanged: (val) {
                      setDialogState(() => delay = val.toInt());
                    },
                  ),
                  const Text("Higher delay = Safer for sender", style: TextStyle(color: Colors.white30, fontSize: 10, fontStyle: FontStyle.italic)),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => _addToSequence(item, count, delay),
                  child: const Text("ADD TO QUEUE", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                )
              ],
            );
          }
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("Custom Payload Builder", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: Colors.white)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SaturnXBackground(
      child: isFetchingData 
        ? const Center(child: CircularProgressIndicator(color: Colors.purpleAccent))
        : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Target Input
            _buildGlassCard(
              child: TextField(
                controller: _targetController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: "Target Number",
                  labelStyle: TextStyle(color: Colors.purpleAccent),
                  hintText: "628xxx",
                  hintStyle: TextStyle(color: Colors.white24),
                  prefixIcon: Icon(Icons.phone_android, color: Colors.white54),
                  border: InputBorder.none,
                ),
                keyboardType: TextInputType.phone,
              ),
            ),
            const SizedBox(height: 16),

            // SENDER SELECTION (PURE SELECTION ONLY)
             const Text("Select Your Sender", style: TextStyle(color: Colors.white54, fontSize: 12)),
             const SizedBox(height: 5),
             Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF1A052E),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.purpleAccent.withOpacity(0.3))
              ),
              child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: selectedSender,
                    dropdownColor: const Color(0xFF0F021D),
                    isExpanded: true,
                    icon: const Icon(Icons.arrow_drop_down, color: Colors.purpleAccent),
                    hint: const Text("No Senders Found (Pair in Dashboard)", style: TextStyle(color: Colors.red)),
                    items: mySenders.map((sender) {
                      return DropdownMenuItem<String>(
                        value: sender['sessionName'].toString(),
                        child: Row(
                          children: [
                            const FaIcon(FontAwesomeIcons.whatsapp, color: Colors.green, size: 18),
                            const SizedBox(width: 10),
                            Expanded(child: Text(sender['sessionName'], style: const TextStyle(color: Colors.white), overflow: TextOverflow.ellipsis)),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (val) => setState(() => selectedSender = val),
                  ),
                ),
            ),
            
            if (mySenders.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 8.0),
                child: Text(
                  "* Please go back to Dashboard > Manage Bug Sender to pair your WhatsApp.",
                  style: TextStyle(color: Colors.white30, fontSize: 10, fontStyle: FontStyle.italic),
                ),
              ),

            const SizedBox(height: 24),
            
            // Queue List
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Payload List", style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                if (attackSequence.isNotEmpty)
                  IconButton(
                    onPressed: () => setState(() => attackSequence.clear()),
                    icon: const Icon(Icons.delete_sweep, color: Colors.red),
                    tooltip: "Clear All",
                  )
              ],
            ),
            const SizedBox(height: 10),
            
            Container(
              height: 320,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.3),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white10)
              ),
              child: attackSequence.isEmpty 
                ? const Center(child: Text("Empty Payload\nTap '+' to add payload", textAlign: TextAlign.center, style: TextStyle(color: Colors.white30)))
                : ReorderableListView(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    onReorder: (oldIndex, newIndex) {
                      setState(() {
                        if (newIndex > oldIndex) newIndex -= 1;
                        final item = attackSequence.removeAt(oldIndex);
                        attackSequence.insert(newIndex, item);
                      });
                    },
                    children: [
                      for (int i = 0; i < attackSequence.length; i++)
                        ListTile(
                          key: ValueKey(i),
                          leading: _buildIconOrEmoji(attackSequence[i]['icon_raw']),
                          title: Text(attackSequence[i]['name'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          subtitle: Row(
                            children: [
                              Text("${attackSequence[i]['count']}x", style: const TextStyle(color: Colors.purpleAccent, fontWeight: FontWeight.bold)),
                              const SizedBox(width: 8),
                              const Text("|", style: TextStyle(color: Colors.white24)),
                              const SizedBox(width: 8),
                              Text("${attackSequence[i]['delay']}ms", style: const TextStyle(color: Colors.cyanAccent)),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.drag_handle, color: Colors.white.withOpacity(0.3)),
                              const SizedBox(width: 8),
                              IconButton(
                                icon: const Icon(Icons.remove_circle_outline, color: Colors.redAccent),
                                onPressed: () => setState(() => attackSequence.removeAt(i)),
                              ),
                            ],
                          ),
                        )
                    ],
                  ),
            ),
            
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white10,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 16)
                    ),
                    onPressed: _showPayloadSelector,
                    icon: const Icon(Icons.add, color: Colors.white),
                    label: const Text("ADD PAYLOAD"),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFB027F6),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 16)
                    ),
                    onPressed: isLoading ? null : _executeAttack,
                    icon: isLoading 
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.rocket_launch),
                    label: const Text("LAUNCH PAYLOAD", style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
     ), 
   );
  }
  
  Widget _buildGlassCard({required Widget child}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1A052E).withOpacity(0.6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.purpleAccent.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(color: Colors.purple.withOpacity(0.1), blurRadius: 10, spreadRadius: 1)
        ]
      ),
      child: child,
    );
  }
}
