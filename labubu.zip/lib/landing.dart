import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'constants.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _controller;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

    void _initVideo() {
  _controller = VideoPlayerController.asset(
    "assets/videos/banner.mp4",
    // PERBAIKAN: videoPlayerOptions harus di dalam kurung asset(...)
    videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true), 
  )..initialize().then((_) {
      setState(() {
        _isVideoInitialized = true;
      });
      _controller.setLooping(true);
      _controller.setVolume(0);
      _controller.play();
    });
}

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      debugPrint("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    // Ukuran layar untuk responsivitas
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: primaryDark,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 1. BACKGROUND VIDEO (Full Screen)
          if (_isVideoInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _controller.value.size.width,
                height: _controller.value.size.height,
                child: VideoPlayer(_controller),
              ),
            )
          else
            Container(color: primaryDark),

          // 2. OVERLAY GRADIENT (Agar teks terbaca & nuansa gelap)
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  primaryDark.withOpacity(0.3),
                  primaryDark.withOpacity(0.6),
                  primaryDark.withOpacity(0.95), // Bawah makin gelap
                ],
                stops: const [0.0, 0.6, 1.0],
              ),
            ),
          ),

          // 3. MAIN CONTENT
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // --- HEADER: Logo Kecil & Versi ---
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Logo Box (Kiri)
                      _buildGlassContainer(
                        borderRadius: 12,
                        padding: const EdgeInsets.all(2), // Border effect
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset(
                            "assets/images/logo.jpg",
                            width: 40,
                            height: 40,
                            fit: BoxFit.cover,
                            errorBuilder: (c, o, s) => Container(
                              width: 40, height: 40, color: Colors.black,
                              child: const Icon(Icons.code, color: accentPink),
                            ),
                          ),
                        ),
                      ),
                      
                      // Version Pill (Kanan)
                      _buildGlassContainer(
                        borderRadius: 20,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: const Text(
                          "v7.0 Stable",
                          style: TextStyle(
                            color: accentPink,
                            fontFamily: 'Courier',
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const Spacer(flex: 1), // Ruang fleksibel

                  // --- HERO CARD (Mirip Foto 1) ---
                  // Kartu besar di tengah dengan visual keren
                  Container(
                    width: double.infinity,
                    height: size.height * 0.28, // Sekitar 30% layar
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: accentPink.withOpacity(0.3), width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: accentPink.withOpacity(0.15),
                          blurRadius: 30,
                          offset: const Offset(0, 10),
                        ),
                      ],
                      // Gradient Background mirip style kartu di foto 1
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          cardDarker.withOpacity(0.8),
                          deepSpace.withOpacity(0.9),
                        ],
                      ),
                    ),
                    child: Stack(
                      children: [
                        // Hiasan Background dalam kartu (bisa logo transparan besar)
                        Positioned(
                          right: -20,
                          bottom: -20,
                          child: Opacity(
                            opacity: 0.1,
                            child: Icon(Icons.security, size: 150, color: accentPink),
                          ),
                        ),
                        
                        // Center Content
                        Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Visual Mata/Logo di tengah (Ganti dengan Icon/Gambar)
                              Container(
                                width: 70,
                                height: 70,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: accentPink.withOpacity(0.6),
                                      blurRadius: 40,
                                    )
                                  ],
                                  border: Border.all(color: Colors.white, width: 2),
                                  image: const DecorationImage(
                                    image: AssetImage("assets/images/logo.jpg"),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                              
                              // Text Pill "SaturnX > System"
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.6),
                                  borderRadius: BorderRadius.circular(30),
                                  border: Border.all(color: accentPink.withOpacity(0.5)),
                                ),
                                child: RichText(
                                  text: const TextSpan(
                                    style: TextStyle(fontFamily: 'Courier', fontSize: 16),
                                    children: [
                                      TextSpan(
                                        text: "SaturnX ",
                                        style: TextStyle(
                                            color: Colors.white, fontWeight: FontWeight.bold),
                                      ),
                                      TextSpan(
                                        text: "⚡ ",
                                        style: TextStyle(color: accentPink, fontSize: 14),
                                      ),
                                      TextSpan(
                                        text: "System",
                                        style: TextStyle(
                                            color: Colors.white70, fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Spacer(flex: 1), // Ruang fleksibel

                  // --- BUTTONS SECTION ---
                  Column(
                    children: [
                      // Tombol LOGIN (Solid, Glowing)
                      Container(
                        width: double.infinity,
                        height: 55,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: primaryPink.withOpacity(0.4),
                              blurRadius: 15,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: () => Navigator.pushNamed(context, "/login"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: cardDarker, // Gelap
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                              side: const BorderSide(color: accentPink, width: 1), // Border Neon
                            ),
                            elevation: 0,
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.login_rounded, color: accentPink),
                              SizedBox(width: 12),
                              Text(
                                "Login Access",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                  fontFamily: 'Courier',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 16),

                      // Tombol REGISTER (Outlined)
                      SizedBox(
                        width: double.infinity,
                        height: 55,
                        child: OutlinedButton(
                          onPressed: () => _openUrl("https://t.me/Kyxsancs"),
                          style: OutlinedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            side: const BorderSide(color: successGreen, width: 1.5),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            foregroundColor: successGreen,
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.app_registration_rounded, size: 20),
                              SizedBox(width: 12),
                              Text(
                                "Register",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                  fontFamily: 'Courier',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 40),

                  // --- FOOTER: CONNECT WITH US ---
                  Column(
                    children: [
                      const Text(
                        "Connect With Us",
                        style: TextStyle(
                          color: successGreen,
                          fontFamily: 'Courier',
                          fontSize: 12,
                          letterSpacing: 2,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                       _buildSocialIcon(FontAwesomeIcons.telegram, "https://t.me/Kyxsancs"),
                          const SizedBox(width: 20),
                          _buildSocialIcon(FontAwesomeIcons.tiktok, "https://tiktok.com/@official_kyxzantzy"),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Text(
                        "© 2026 SaturnX System - @Kyxsancs",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Helper Widget: Glass Container
  Widget _buildGlassContainer({required Widget child, required double borderRadius, required EdgeInsetsGeometry padding}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: cardDarker.withOpacity(0.4),
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(color: accentPink.withOpacity(0.3), width: 1),
          ),
          child: child,
        ),
      ),
    );
  }

  // Helper Widget: Social Icon Button
  Widget _buildSocialIcon(IconData icon, String url) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: cardDarker.withOpacity(0.6),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: successGreen.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: successGreen.withOpacity(0.1),
              blurRadius: 8,
              spreadRadius: 1
            )
          ],
        ),
        child: FaIcon(icon, color: successGreen, size: 20),
      ),
    );
  }
}
