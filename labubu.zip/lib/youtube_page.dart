import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'constants.dart';

// --- MODEL DATA VIDEO ---
class VideoData {
  final String id;
  final String title;
  final String author;
  final String thumbnail;

  VideoData({
    required this.id,
    required this.title,
    required this.author,
    required this.thumbnail,
  });
}

// --- GLOBAL NOTIFIER ---
final ValueNotifier<VideoData?> globalVideoNotifier = ValueNotifier<VideoData?>(null);

class YoutubeSearchPage extends StatefulWidget {
  const YoutubeSearchPage({super.key});

  @override
  State<YoutubeSearchPage> createState() => _YoutubeSearchPageState();
}

class _YoutubeSearchPageState extends State<YoutubeSearchPage> {
  final TextEditingController _searchController = TextEditingController();
  List<dynamic> _searchResults = [];
  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _searchYoutube() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _searchResults = [];
    });

    try {
      final url = Uri.parse("https://qwerty-api.cloud/sr/yt?query=$query");
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        // --- PARSING SESUAI JSON BARU ---
        if (data['status'] == true && data['result'] != null) {
          setState(() {
            _searchResults = (data['result'] as List).where((item) {
              // Filter biar aman, pastikan ada videoId
              return item['type'] == 'video' && item['videoId'] != null;
            }).toList();
          });
        } else {
          setState(() => _errorMessage = "Tidak ditemukan hasil.");
        }
      } else {
        setState(() => _errorMessage = "API Error: ${response.statusCode}");
      }
    } catch (e) {
      setState(() => _errorMessage = "Error: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _playVideo(dynamic video) {
    // Ambil data dengan aman (Null Safety)
    final videoId = video['videoId'];
    final title = video['title'] ?? "Unknown Title";
    // Handle author object dari JSON baru
    final authorName = video['author'] is Map ? video['author']['name'] : (video['author'] ?? "Unknown Artist");
    final thumbnail = video['thumbnail'] ?? "";

    // Update Global Player
    globalVideoNotifier.value = VideoData(
      id: videoId,
      title: title,
      author: authorName,
      thumbnail: thumbnail,
    );
    
    FocusScope.of(context).unfocus();
    
    // Feedback visual (Snackbar kecil)
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.music_note, color: accentPink, size: 20),
            const SizedBox(width: 10),
            Expanded(child: Text("Playing: $title", maxLines: 1, overflow: TextOverflow.ellipsis)),
          ],
        ),
        backgroundColor: const Color(0xFF222222),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.only(bottom: 160, left: 16, right: 16), // Di atas player
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        title: const Text("SaturnX Music", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: primaryDark,
        elevation: 0,
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: Colors.white10),
              ),
              child: TextField(
                controller: _searchController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: "Search songs, artists...",
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.search, color: Colors.white.withOpacity(0.5)),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.send_rounded, color: successGreen),
                    onPressed: _searchYoutube,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
                onSubmitted: (_) => _searchYoutube(),
              ),
            ),
          ),

          // List Result
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: accentPink))
                : _searchResults.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.music_note_rounded, size: 60, color: Colors.white.withOpacity(0.1)),
                          const SizedBox(height: 10),
                          Text("Search for music", style: TextStyle(color: Colors.white.withOpacity(0.3))),
                        ],
                      ),
                    )
                  : ListView.separated(
                      itemCount: _searchResults.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 160), 
                      itemBuilder: (context, index) {
                        final video = _searchResults[index];
                        return _buildVideoCard(video);
                      },
                    ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoCard(dynamic video) {
    final authorName = video['author'] is Map ? video['author']['name'] : "Unknown";
    final timestamp = video['timestamp'] ?? video['duration']?['timestamp'] ?? "";

    return InkWell(
      onTap: () => _playVideo(video),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1A), // Warna card gelap
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.transparent),
        ),
        child: Row(
          children: [
            // Thumbnail
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                video['thumbnail'] ?? "",
                height: 55,
                width: 55,
                fit: BoxFit.cover,
                errorBuilder: (_,__,___) => Container(height: 55, width: 55, color: Colors.grey[900]),
              ),
            ),
            const SizedBox(width: 14),
            
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    video['title'] ?? "No Title",
                    style: const TextStyle(
                      color: Colors.white, 
                      fontWeight: FontWeight.w600, 
                      fontSize: 14
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.person, size: 12, color: Colors.white38),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          authorName,
                          style: const TextStyle(color: Colors.white38, fontSize: 12),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            // Duration & Action
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  timestamp,
                  style: const TextStyle(color: Colors.white38, fontSize: 12, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Icon(Icons.play_circle_outline, color: Colors.white24, size: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
