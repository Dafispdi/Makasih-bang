import 'dart:convert';
import 'dart:ui'; // Wajib buat ImageFilter
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'bug_group_page.dart'; 
import 'constants.dart';

Route glitchRoute(Widget page, String username) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      return AnimatedBuilder(
        animation: animation,
        builder: (context, child) {
          final double offset = (animation.value < 1.0)
              ? (animation.value % 0.1 > 0.05 ? 5.0 : -5.0)
              : 0.0;
          return Transform.translate(
            offset: Offset(offset, 0),
            child: Opacity(
              opacity: animation.value % 0.2 > 0.1 ? 0.8 : 1.0,
              child: child,
            ),
          );
        },
        child: child,
      );
    },
    transitionDuration: const Duration(milliseconds: 300),
  );
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  int globalSendersCount = 0;
  bool checkingGlobal = true;
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _pulseController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _pulseAnimation;

  String selectedBugId = "";
  bool _isSending = false;

  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000));
    _slideController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);

    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut);
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));

    _fadeController.forward();
    _slideController.forward();

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
    _initializeVideoPlayer();
    _checkGlobalStatus();
  }

  Future<void> _checkGlobalStatus() async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/stats'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({"type": "stats"}),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            globalSendersCount = data['activeConnections'] ?? 0;
            checkingGlobal = false;
          });
        }
      } else {
        if (mounted) setState(() => checkingGlobal = false); 
      }
    } catch (e) {
      if (mounted) setState(() => checkingGlobal = false);
    }
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
          allowFullScreen: false,
          allowMuting: false,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      debugPrint("Video Error: $error");
      setState(() => _isVideoInitialized = false);
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    if (_isVideoInitialized) {
      _videoController.dispose();
      _chewieController.dispose();
    }
    super.dispose();
  }

  Widget _buildNavigationMenu() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BugGroupPage(
              sessionKey: widget.sessionKey,
              userId: widget.username,
              role: widget.role,
            ),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: dangerRed.withOpacity(0.5), width: 1),
          boxShadow: [BoxShadow(color: dangerRed.withOpacity(0.2), blurRadius: 10, spreadRadius: 1)],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: dangerRed.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.groups_3, color: Colors.red, size: 28),
            ),
            const SizedBox(width: 16),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("BUG GROUP MENU", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.2, fontFamily: 'Orbitron')),
                  Text("Raid all member group", style: TextStyle(color: Colors.white60, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.red, size: 18),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _buildHeaderSection(),
                const SizedBox(height: 24),
                _buildSenderStatus(),
                const SizedBox(height: 16),
                _buildVideoSection(),
                const SizedBox(height: 24),
                _buildNavigationMenu(),
                const SizedBox(height: 24),
                _buildControlPanel(), // Disini layout barunya
                const SizedBox(height: 24),
                _buildSendButton(),
                const SizedBox(height: 16)
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSenderStatus() {
    bool isOwner = widget.role.toLowerCase() == 'owner';
    
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF1A052E).withOpacity(0.8),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentPink.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.shield_moon, color: accentPink, size: 14),
          const SizedBox(width: 8),
          Text(
            isOwner ? "SENDER TYPE : GLOBAL SENDER" : "SENDER TYPE : PRIVATE SENDER",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(colors: [primaryPink, accentPink], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) => Transform.scale(
              scale: _pulseAnimation.value,
              child: Container(
                width: 60, height: 60,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white30, width: 2)),
                child: ClipOval(child: Image.asset('assets/images/logo.jpg', fit: BoxFit.cover)),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.username, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                Text(widget.role.toUpperCase(), style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          Text(widget.expiredDate, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildVideoSection() {
    return Container(
      width: double.infinity, height: 200,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: cardDark),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: _isVideoInitialized 
            ? Chewie(controller: _chewieController) 
            : const Center(child: CircularProgressIndicator(color: Color(0xFFB027F6))),
      ),
    );
  }

  Widget _buildControlPanel() {
    return Container(
      width: double.infinity, padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: cardDark, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildModernInput(controller: targetController, label: "Target Number", hint: "+62xxx", icon: Icons.phone_android),
          const SizedBox(height: 24),
          
          // --- HEADER SELECTION ---
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Select Payloads", style: TextStyle(color: Color(0xFF08D9D6), fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              Text(
                selectedBugId.isNotEmpty ? "1 selected" : "0 selected", 
                style: const TextStyle(color: Colors.white54, fontSize: 12)
              ),
            ],
          ),
          const SizedBox(height: 12),

          // --- GRID SELECTOR BARU ---
          _buildBugSelectorGrid(),
        ],
      ),
    );
  }

  // --- WIDGET GRID SELECTOR (Style Foto 1) ---
// ... imports tetap sama

  // --- HAPUS method _buildBugSelectorGrid yang lama, GANTI dengan yang ini ---
  
  Widget _buildBugSelectorGrid() {
    if (widget.listBug.isEmpty) {
      return const Center(
        child: Text("No Bugs Available", style: TextStyle(color: Colors.white30))
      );
    }

    return SizedBox(
      height: 120, // Tinggi area scroll horizontal
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: widget.listBug.length,
        separatorBuilder: (context, index) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final bug = widget.listBug[index];
          final bool isSelected = selectedBugId == bug['bug_id'];
          
          return GestureDetector(
            onTap: () {
              setState(() {
                selectedBugId = bug['bug_id'];
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
              width: 140, // Lebar kartu fixed
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                // Background lebih gelap/matte, bukan gradient neon penuh
                color: isSelected 
                    ? const Color(0xFF2A0944).withOpacity(0.8) // Sedikit ungu tua jika aktif
                    : const Color(0xFF121212), // Hitam matte jika tidak aktif
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  // Border menyala tipis jika dipilih, abu-abu gelap jika tidak
                  color: isSelected ? accentPink : Colors.white10,
                  width: isSelected ? 1.5 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: accentPink.withOpacity(0.2),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        )
                      ]
                    : [],
              ),
              child: Stack(
                children: [
                  // Konten Utama (Icon & Teks)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Icon di pojok kiri atas
                      Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isSelected ? accentPink.withOpacity(0.2) : Colors.white.withOpacity(0.05),
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        bug['icon'] ?? "👾", // Render Emoji sebagai Text
                        style: const TextStyle(
                          fontSize: 20, // Ukuran emoji
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                      
                      // Teks di bagian bawah
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            bug['bug_name'].toString().toUpperCase(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              fontFamily: 'Orbitron',
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            bug['bug_id'],
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: isSelected ? accentPink : Colors.white30,
                              fontSize: 10,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  // Indikator Centang Hijau (Pojok Kanan Atas)
                  // Hanya muncul jika isSelected = true
                  if (isSelected)
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          color: Color(0xFF00C853), // Warna Hijau WhatsApp/Success
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check,
                          size: 10,
                          color: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildModernInput({required TextEditingController controller, required String label, required String hint, required IconData icon}) {
    return Container(
      decoration: BoxDecoration(
        color: cardDarker,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF08D9D6).withOpacity(0.3))
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.phone,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        decoration: InputDecoration(
          icon: Icon(icon, color: const Color(0xFF08D9D6)),
          labelText: label, labelStyle: const TextStyle(color: Colors.white54),
          hintText: hint, hintStyle: const TextStyle(color: Colors.white24),
          border: InputBorder.none,
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    return SizedBox(
      width: double.infinity, height: 55,
      child: ElevatedButton(
        onPressed: _isSending ? null : _sendBug,
        style: ElevatedButton.styleFrom(
          backgroundColor: accentPink, 
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          shadowColor: accentPink.withOpacity(0.5),
          elevation: 10,
        ),
        child: _isSending 
            ? const CircularProgressIndicator(color: Colors.white) 
            : const Text("LAUNCH ATTACK", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 16, fontFamily: 'Orbitron')),
      ),
    );
  }

  Future<void> _sendBug() async {
    final target = targetController.text.trim();
    
    if (target.isEmpty) {
      _showCyberAlert(
        false, 
        "INPUT COLOM ERROR", 
        {"ERROR": "Target Empty", "CODE": "400"}
      );
      return;
    }

    final bugName = widget.listBug.firstWhere(
      (element) => element['bug_id'] == selectedBugId, 
      orElse: () => {'bug_name': 'Unknown Payload'}
    )['bug_name'];

    setState(() => _isSending = true);

    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/sendBug?key=${widget.sessionKey}&target=$target&bug=$selectedBugId"));
      
      final data = jsonDecode(res.body);
      final bool isSuccess = data['sended'] == true;
      final String statusMsg = isSuccess ? "INJECTED" : "FAILED";
      final String senderType = data['senderType'] ?? "Unknown";

      final Map<String, String> logDetails = {
        "PAYLOAD": bugName,
        "TARGET": target,
        "STATUS": statusMsg,
        "SENDER": senderType,
        "TIMESTAMP": "${DateTime.now().hour}:${DateTime.now().minute}",
      };

      if (mounted) {
        _showCyberAlert(
          isSuccess, 
          isSuccess ? "ATTACK LAUNCHED" : "ATTACK FAILED",
          logDetails
        );
      }

    } catch (e) {
      if (mounted) {
        _showCyberAlert(
          false, 
          "CONNECTION ERROR",
          {"STATUS": "Offline", "REASON": "Server Unreachable"}
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isSending = false);
      }
    }
  }

  void _showCyberAlert(bool success, String title, Map<String, String> details) {
    if (!_isVideoInitialized) return; 

    showDialog(
      context: context,
      barrierDismissible: false, 
      barrierColor: Colors.black.withOpacity(0.85), 
      builder: (context) {
        return CyberVideoAlert(
          videoController: _videoController, 
          isSuccess: success,
          title: title,
          details: details, 
          onClosed: () {
            if (success) {
              targetController.clear();
            }
          },
        );
      },
    );
  }
}

class CyberVideoAlert extends StatelessWidget {
  final VideoPlayerController videoController;
  final bool isSuccess;
  final String title;
  final Map<String, String> details; 
  final VoidCallback onClosed;

  const CyberVideoAlert({
    Key? key,
    required this.videoController,
    required this.isSuccess,
    required this.title,
    required this.details,
    required this.onClosed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colorTheme = isSuccess ? const Color(0xFF10B981) : const Color(0xFFFF2D55);
    final icon = isSuccess ? Icons.check_circle_outline : Icons.warning_amber_rounded;
    final headerText = isSuccess ? "SYSTEM SUCCESS" : "SYSTEM FAILURE";

    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 400),
        tween: Tween<double>(begin: 0.8, end: 1.0),
        curve: Curves.elasticOut,
        builder: (context, double scale, child) {
          return Transform.scale(
            scale: scale,
            child: child,
          );
        },
        child: Container(
          width: 340,
          constraints: const BoxConstraints(minHeight: 420),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: colorTheme.withOpacity(0.8), width: 2),
            boxShadow: [
              BoxShadow(
                color: colorTheme.withOpacity(0.4),
                blurRadius: 30,
                spreadRadius: 2,
              )
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              children: [
                Positioned.fill(
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: videoController.value.size.width,
                      height: videoController.value.size.height,
                      child: VideoPlayer(videoController),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.8),
                          colorTheme.withOpacity(0.3), 
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
                    child: Container(color: Colors.transparent),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min, 
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TweenAnimationBuilder(
                        tween: Tween<double>(begin: 1.0, end: 1.2),
                        duration: const Duration(seconds: 1),
                        builder: (context, scale, child) => Transform.scale(scale: scale, child: child),
                        child: Icon(icon, color: colorTheme, size: 70),
                      ),
                      const SizedBox(height: 15),
                      Text(
                        headerText,
                        style: TextStyle(
                          color: colorTheme,
                          fontFamily: 'Orbitron',
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          shadows: [Shadow(color: colorTheme, blurRadius: 15)],
                        ),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: colorTheme.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "// EXECUTION LOG",
                              style: TextStyle(
                                color: colorTheme.withOpacity(0.7),
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                letterSpacing: 1.5,
                              ),
                            ),
                            const Divider(color: Colors.white24, height: 10),
                            ...details.entries.map((entry) {
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      entry.key.toUpperCase(),
                                      style: const TextStyle(
                                        color: Colors.white60,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 12,
                                      ),
                                    ),
                                    Expanded(
                                      child: Text(
                                        entry.value,
                                        textAlign: TextAlign.right,
                                        style: TextStyle(
                                          color: colorTheme,
                                          fontFamily: 'ShareTechMono',
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 25),
                      SizedBox(
                        width: double.infinity,
                        height: 45,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                            onClosed();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: colorTheme.withOpacity(0.8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 10,
                            shadowColor: colorTheme.withOpacity(0.5),
                          ),
                          child: const Text(
                            "ACKNOWLEDGE",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                              fontFamily: 'Orbitron'
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
