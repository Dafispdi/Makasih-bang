import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'constants.dart';
import 'youtube_page.dart';

class GlobalPlayerOverlay extends StatefulWidget {
  final Widget child;

  const GlobalPlayerOverlay({super.key, required this.child});

  @override
  State<GlobalPlayerOverlay> createState() => _GlobalPlayerOverlayState();
}

class _GlobalPlayerOverlayState extends State<GlobalPlayerOverlay> {
  YoutubePlayerController? _ytController;
  VideoData? _currentData;
  bool _isPlaying = false;
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    globalVideoNotifier.addListener(_onVideoChanged);
  }

  void _onVideoChanged() {
    final data = globalVideoNotifier.value;
    if (data != null) {
      if (_currentData?.id != data.id) {
        _initializePlayer(data.id);
      }
      setState(() {
        _currentData = data;
      });
    } else {
      _disposePlayer();
    }
  }

  void _initializePlayer(String videoId) {
    _ytController?.dispose();
    _ytController = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: false,
        hideControls: true,
        forceHD: false,
        loop: true,
        isLive: false,
      ),
    )..addListener(_playerListener);
  }

  void _disposePlayer() {
    _ytController?.dispose();
    _ytController = null;
    if (mounted) {
      setState(() {
        _currentData = null;
        _isPlaying = false;
        _progress = 0.0;
      });
    }
  }

  void _playerListener() {
    if (_ytController != null && mounted) {
      setState(() {
        _isPlaying = _ytController!.value.isPlaying;
        final duration = _ytController!.value.metaData.duration.inMilliseconds;
        final position = _ytController!.value.position.inMilliseconds;
        if (duration > 0) _progress = position / duration;
      });
    }
  }

  @override
  void dispose() {
    globalVideoNotifier.removeListener(_onVideoChanged);
    _ytController?.dispose();
    super.dispose();
  }

  void _togglePlayPause() {
    if (_ytController != null) {
      _isPlaying ? _ytController!.pause() : _ytController!.play();
    }
  }

  void _closePlayer() {
    globalVideoNotifier.value = null;
  }

  @override
  Widget build(BuildContext context) {
    bool isActive = _currentData != null && _ytController != null;

    return Stack(
      children: [
        // 1. APLIKASI UTAMA
        widget.child,

        // 2. HIDDEN PLAYER (Wajib ada biar suara keluar, tapi kita sembunyikan)
        if (isActive)
          Opacity(
            opacity: 0.0, // Invisible
            child: SizedBox(
              width: 1, 
              height: 1,
              child: YoutubePlayer(
                controller: _ytController!,
                onReady: () {
                   _ytController!.unMute();
                   _ytController!.setVolume(100);
                },
              ),
            ),
          ),

        // 3. UI VISUAL PLAYER (Tampilan Keren ala Video)
        if (isActive)
          Positioned(
            left: 12,
            right: 12,
            bottom: 85, // Di atas Navbar
            child: Dismissible(
              key: const Key('mini-player'),
              direction: DismissDirection.down,
              onDismissed: (_) => _closePlayer(),
              child: Container(
                height: 70,
                decoration: BoxDecoration(
                  color: const Color(0xFF151515).withOpacity(0.95), // Dark solid background
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white10, width: 0.5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    children: [
                      // ISI KONTEN
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Row(
                          children: [
                            // THUMBNAIL (Gambar Album Art)
                            Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[900],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.network(
                                  _currentData!.thumbnail,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_,__,___) => const Icon(Icons.music_note, color: Colors.white24),
                                ),
                              ),
                            ),
                            
                            const SizedBox(width: 12),

                            // JUDUL & ARTIS
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _currentData!.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white, 
                                      fontWeight: FontWeight.w600, 
                                      fontSize: 13,
                                      fontFamily: 'Orbitron'
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    _currentData!.author,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.6), 
                                      fontSize: 11
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // TOMBOL CONTROL
                            IconButton(
                              icon: Icon(
                                _isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled, 
                                color: successGreen, // Hijau Neon sesuai tema
                                size: 36
                              ),
                              onPressed: _togglePlayPause,
                              splashColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                            ),
                            
                            IconButton(
                              icon: const Icon(Icons.close, color: Colors.white54, size: 22),
                              onPressed: _closePlayer,
                              splashColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                            ),
                          ],
                        ),
                      ),

                      // PROGRESS BAR (Di bagian paling bawah)
                      Positioned(
                        bottom: 0, 
                        left: 0, 
                        right: 0,
                        child: LinearProgressIndicator(
                          value: _progress.isNaN ? 0 : _progress,
                          backgroundColor: Colors.transparent,
                          valueColor: const AlwaysStoppedAnimation<Color>(successGreen),
                          minHeight: 2, // Tipis elegan
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
