import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'constants.dart';

class TestFunctionPage extends StatefulWidget {
  final String sessionKey;

  const TestFunctionPage({super.key, required this.sessionKey});

  @override
  State<TestFunctionPage> createState() => _TestFunctionPageState();
}

class _TestFunctionPageState extends State<TestFunctionPage> {
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _delayController = TextEditingController(text: "1000");
  final TextEditingController _loopController = TextEditingController(text: "1");

  bool _isLoading = false;
  List<String> _executionLogs = []; // Variabel untuk menampung log

  // Default code template
  final String _defaultCode = """
async function EhokepJink(sock, target) {
  console.log('Preparing message...');
  await sock.sendMessage(target, { text: 'Test Function Wroking!' });
  console.log('Message sent sukcess!');
}
""";

  @override
  void initState() {
    super.initState();
    _codeController.text = _defaultCode;
  }

  Future<void> _executeFunction() async {
    if (_targetController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Target is required!")),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _executionLogs = ["Waiting for server response..."]; // Reset log
    });

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/tester/execute'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "key": widget.sessionKey,
          "target": _targetController.text.trim(), // TAMBAHKAN .trim() DISINI
          "code": _codeController.text,
          "delay": int.tryParse(_delayController.text) ?? 1000,
          "loop": int.tryParse(_loopController.text) ?? 1,
        }),
      );

      final data = jsonDecode(response.body);

      setState(() {
        // Ambil logs dari response server
        if (data['logs'] != null) {
          _executionLogs = List<String>.from(data['logs']);
        } else {
          _executionLogs.add("No logs returned from server.");
        }
      });

      if (data['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
           const SnackBar(backgroundColor: successGreen, content: Text("Execution Finished")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(backgroundColor: dangerRed, content: Text(data['message'] ?? "Failed")),
        );
      }
    } catch (e) {
      setState(() {
        _executionLogs.add("CLIENT ERROR: $e");
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: dangerRed, content: Text("Error: $e")),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("Test Function", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Colors.cyan.shade900, Colors.cyanAccent.shade700]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.code, color: Colors.white, size: 30),
                  ),
                  const SizedBox(width: 15),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Function Tester", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                        Text("Supports Number (628xx) or Group Link", style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),

            // Target Input (UPDATED)
            const Text("Target (Nomor / Link Group)", style: TextStyle(color: accentPink, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _targetController,
              keyboardType: TextInputType.text, // Ganti ke text agar bisa paste link
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                filled: true,
                fillColor: cardDarker,
                hintText: "628xx / https://chat.whatsapp.com/...",
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                prefixIcon: const Icon(Icons.hub, color: accentPink), // Icon diganti biar relevan sama group
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),

            // Code Input
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Function / Message", style: TextStyle(color: accentPink, fontWeight: FontWeight.bold)),
                GestureDetector(
                  onTap: () {
                    setState(() => _codeController.clear());
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
                    child: const Text("Clear", style: TextStyle(color: Colors.red, fontSize: 12)),
                  ),
                )
              ],
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: cardDarker,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentPink.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _codeController,
                maxLines: 8,
                style: const TextStyle(color: Color(0xFF00FF00), fontFamily: 'Courier', fontSize: 14), 
                decoration: const InputDecoration(
                  contentPadding: EdgeInsets.all(15),
                  border: InputBorder.none,
                  hintText: "Paste your function here...",
                  hintStyle: TextStyle(color: Colors.grey),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Config Row (Delay & Loop)
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Delay (ms)", style: TextStyle(color: Colors.white70)),
                      const SizedBox(height: 5),
                      TextField(
                        controller: _delayController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: cardDarker,
                          prefixIcon: const Icon(Icons.timer, color: Colors.orange, size: 18),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Jumlah Loops", style: TextStyle(color: Colors.white70)),
                      const SizedBox(height: 5),
                      TextField(
                        controller: _loopController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: cardDarker,
                          prefixIcon: const Icon(Icons.repeat, color: Colors.blue, size: 18),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 25),

            // Execute Button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _executeFunction,
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentPink,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text("EXECUTE CODE", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),

            const SizedBox(height: 30),
            
            // --- CONSOLE OUTPUT UI ---
            const Text("Server Console Logs:", style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              height: 200,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black, // Warna terminal
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.withOpacity(0.3)),
              ),
              child: _executionLogs.isEmpty
                  ? const Center(child: Text("No logs yet.", style: TextStyle(color: Colors.grey)))
                  : ListView.builder(
                      itemCount: _executionLogs.length,
                      itemBuilder: (context, index) {
                        final log = _executionLogs[index];
                        // Warna log berbeda jika error
                        Color logColor = Colors.greenAccent;
                        if (log.contains("[ERROR]") || log.contains("[VM ERROR]")) {
                          logColor = Colors.redAccent;
                        } else if (log.contains("[SYSTEM]")) {
                          logColor = Colors.cyanAccent;
                        }
                        
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 4.0),
                          child: Text(
                            log,
                            style: TextStyle(
                              color: logColor,
                              fontFamily: 'Courier',
                              fontSize: 12,
                            ),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 50), 
          ],
        ),
      ),
    );
  }
}
