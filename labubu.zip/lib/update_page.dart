import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'dart:io';
import 'constants.dart'; 

class UpdatePage extends StatefulWidget {
  final Map<String, dynamic> updateData;

  const UpdatePage({Key? key, required this.updateData}) : super(key: key);

  @override
  State<UpdatePage> createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage> {
  bool isDownloading = false;
  double downloadProgress = 0.0;
  String downloadStatus = "Siap Mengunduh";
  String currentVersion = "Loading...";
  CancelToken cancelToken = CancelToken();

  @override
  void initState() {
    super.initState();
    _getAppVersion();
  }

  @override
  void dispose() {
    if (isDownloading) {
      cancelToken.cancel(); // Batalkan download jika keluar halaman
    }
    super.dispose();
  }

  Future<void> _getAppVersion() async {
    final info = await PackageInfo.fromPlatform();
    setState(() => currentVersion = info.version);
  }

  Future<void> _startDownload(String url) async {
    // 1. Cek Permission Install Packages (Wajib untuk Android 8+)
    if (await Permission.requestInstallPackages.request().isDenied) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Izinkan aplikasi untuk menginstall update!"))
      );
      await openAppSettings();
      return;
    }

    setState(() {
      isDownloading = true;
      downloadStatus = "Memulai Download...";
      downloadProgress = 0.0;
    });

    try {
      // PERBAIKAN: Gunakan TemporaryDirectory (Cache) agar bisa dibaca oleh Installer
      // getApplicationDocumentsDirectory sering menyebabkan "Parse Error" di Android baru
      final Directory dir = await getTemporaryDirectory();
      
      String savePath = "${dir.path}/update_saturnx.apk";
      File file = File(savePath);

      if (await file.exists()) {
        await file.delete();
      }

      // Download File
      await Dio().download(
        url,
        savePath,
        cancelToken: cancelToken,
        onReceiveProgress: (received, total) {
          if (total != -1) {
            setState(() {
              downloadProgress = received / total;
              downloadStatus = "Downloading... ${(downloadProgress * 100).toStringAsFixed(0)}%";
            });
          }
        },
      );

      // CEK UKURAN FILE (Debugging)
      int fileSize = await file.length();
      if (fileSize < 1000000) { // Jika kurang dari 1MB, kemungkinan file rusak/HTML error
         throw "File corrupt (Size: ${fileSize} bytes). Hubungi Developer agar segera dibetulkan.";
      }

      setState(() => downloadStatus = "Membuka Installer...");

      final result = await OpenFilex.open(
        savePath, 
        type: "application/vnd.android.package-archive" 
      );
      
      if (result.type != ResultType.done) {
        // Tampilkan pesan error detail jika gagal buka
        throw "Gagal Install: ${result.message}";
      }

    } catch (e) {
      // Error handling sama
      if (CancelToken.isCancel(e as dynamic)) {
        setState(() => downloadStatus = "Download Dibatalkan");
      } else {
        setState(() => downloadStatus = "Gagal: $e");
      }
    } finally {
      if (mounted) {
        setState(() => isDownloading = false);
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    String newVersion = widget.updateData['latestVersion'] ?? 'Unknown';
    String fileSize = widget.updateData['fileSize'] ?? 'Unknown Size';
    String rawLogs = widget.updateData['changeLog'] ?? '';
    List<String> features = rawLogs.contains('|') ? rawLogs.split('|') : [rawLogs];
    String downloadUrl = widget.updateData['downloadUrl'] ?? '';

    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("SYSTEM UPDATE", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', letterSpacing: 2)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [cardDark, accentPink.withOpacity(0.2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentPink.withOpacity(0.5)),
                boxShadow: [BoxShadow(color: accentPink.withOpacity(0.1), blurRadius: 20)]
              ),
              child: Column(
                children: [
                  Icon(Icons.rocket_launch, size: 60, color: accentPink),
                  const SizedBox(height: 15),
                  const Text("UPDATE INFORMATION", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18, fontFamily: 'Orbitron')),
                  Text("Versi $newVersion Siap Diinstall", style: TextStyle(color: Colors.white54, fontSize: 12)),
                  const SizedBox(height: 25),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _verInfo("Saat Ini", currentVersion),
                      const Icon(Icons.arrow_forward, color: Colors.white24),
                      _verInfo("Terbaru", newVersion, isNew: true),
                    ],
                  )
                ],
              ),
            ),

            const SizedBox(height: 30),

            Align(alignment: Alignment.centerLeft, child: Text("WHAT'S NEW", style: TextStyle(color: accentPink, fontWeight: FontWeight.bold, letterSpacing: 1.5))),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: cardDarker,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: features.map((feat) => ListTile(
                  leading: const Icon(Icons.check_circle, color: successGreen, size: 20),
                  title: Text(feat, style: const TextStyle(color: Colors.white70, fontSize: 13, fontFamily: 'ShareTechMono')),
                  dense: true,
                )).toList(),
              ),
            ),

            const SizedBox(height: 40),

            if (isDownloading)
              Column(
                children: [
                  LinearProgressIndicator(
                    value: downloadProgress,
                    backgroundColor: cardDarker,
                    color: accentPink,
                    minHeight: 10,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  const SizedBox(height: 10),
                  Text(downloadStatus, style: const TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono')),
                ],
              )
            else
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.download_rounded, color: Colors.white),
                  label: Text("DOWNLOAD & INSTALL ($fileSize)", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentPink,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    shadowColor: accentPink.withOpacity(0.5),
                    elevation: 10
                  ),
                  onPressed: () => _startDownload(downloadUrl),
                ),
              ),
              
            const SizedBox(height: 15),
            const Text("Pastikan koneksi stabil agar download tidak gagal.", style: TextStyle(color: Colors.white24, fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Widget _verInfo(String label, String ver, {bool isNew = false}) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 10)),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isNew ? accentPink.withOpacity(0.2) : Colors.white10,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: isNew ? accentPink : Colors.transparent)
          ),
          child: Text(ver, style: TextStyle(color: isNew ? accentPink : Colors.white70, fontWeight: FontWeight.bold)),
        )
      ],
    );
  }
}
