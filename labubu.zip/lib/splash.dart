import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';
import 'constants.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  late VideoPlayerController _videoController;
  // Kita tidak butuh _initialized untuk state UI lagi
  bool _isNavigating = false;
  Timer? _safetyTimer;

  @override
  void initState() {
    super.initState();
    _initVideoFast();
  }

    void _initVideoFast() {
  _videoController = VideoPlayerController.asset(
    "assets/videos/intro.mp4",
    videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true), 
  );
  
    // 1. SAFETY TIMER: Paksa masuk dashboard jika dalam 5 detik video macet
    _safetyTimer = Timer(const Duration(seconds: 5), () {
        debugPrint("Video timeout/stuck, skipping...");
        _navigateToDashboard();
    });

    _videoController.initialize().then((_) {
      _safetyTimer?.cancel(); 
      
      if (mounted) {
        setState(() {}); 
        
        _videoController.setLooping(false);
        _videoController.setVolume(1.0);
        _videoController.play();

        _videoController.addListener(() {
          if (_videoController.value.position >= _videoController.value.duration) {
            _navigateToDashboard();
          }
        });
      }
    }).catchError((error) {
      debugPrint("Video load error: $error");
      _navigateToDashboard();
    });
  }

  void _navigateToDashboard() {
    if (_isNavigating) return;
    _isNavigating = true;
    _safetyTimer?.cancel();
    
    try { _videoController.removeListener(() {}); } catch (_) {}

    if (mounted) {
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => DashboardPage(
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listDoos: widget.listDoos,
            news: widget.news,
          ),
          transitionsBuilder: (_, animation, __, child) => FadeTransition(opacity: animation, child: child),
          transitionDuration: const Duration(milliseconds: 800),
        ),
      );
    }
  }

  @override
  void dispose() {
    _safetyTimer?.cancel();
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Trik: Cek apakah controller sudah siap.
    // Jika belum, isInitialized nilainya false.
    final isReady = _videoController.value.isInitialized;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _navigateToDashboard, // Tap untuk skip instan
        behavior: HitTestBehavior.opaque,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // LAYER 1: VIDEO PLAYER (Langsung dirender)
            // Jika belum siap, dia akan menampilkan frame kosong (hitam) sebentar
            // tanpa loading spinner.
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  // Gunakan ukuran default jika belum siap untuk menghindari error layout
                  width: isReady ? _videoController.value.size.width : MediaQuery.of(context).size.width,
                  height: isReady ? _videoController.value.size.height : MediaQuery.of(context).size.height,
                  // Tampilkan VideoPlayer hanya jika sudah siap, jika tidak layar hitam
                  child: isReady ? VideoPlayer(_videoController) : Container(color: Colors.black),
                ),
              ),
            ),

            // LAYER 2: TEKS "SaturnX System" (Langsung muncul)
            Positioned(
              bottom: 60,
              left: 0,
              right: 0,
              child: Center(
                child: Column(
                  children: [
                    Text(
                      "SaturnX System",
                      style: TextStyle(
                        fontFamily: 'Courier',
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 4.0,
                        shadows: [
                          Shadow(color: accentPink.withOpacity(0.8), blurRadius: 20),
                          const Shadow(color: Colors.black, blurRadius: 10, offset: Offset(2, 2)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Teks indikator statis
                    Text(
                      "INITIALIZING SYSTEM...",
                      style: TextStyle(
                        color: accentPink.withOpacity(0.5),
                        fontSize: 10,
                        letterSpacing: 2.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
