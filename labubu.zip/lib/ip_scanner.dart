import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'constants.dart';

class IpScannerPage extends StatefulWidget {
  const IpScannerPage({super.key});

  @override
  State<IpScannerPage> createState() => _IpScannerPageState();
}

class _IpScannerPageState extends State<IpScannerPage> {
  final TextEditingController _ipController = TextEditingController();
  bool isLoading = false;
  Map<String, dynamic>? ipData;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchIpDetails(""); // Auto scan IP sendiri saat buka
  }

  Future<void> _fetchIpDetails(String ip) async {
    setState(() {
      isLoading = true;
      errorMessage = null;
      ipData = null;
    });

    try {
      // Menggunakan API Publik Gratis dari ip-api.com
      final url = ip.isEmpty 
          ? "http://ip-api.com/json/" 
          : "http://ip-api.com/json/$ip";
      
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            ipData = data;
          });
        } else {
          setState(() {
            errorMessage = "IP Invalid / Private IP";
          });
        }
      } else {
        setState(() {
          errorMessage = "Server Error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Connection Failed. Check Internet.";
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        title: const Text("IP SCANNER", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Input Section
            Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: cardDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: accentPink.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _ipController,
                style: const TextStyle(color: Colors.white, fontFamily: 'Courier', fontWeight: FontWeight.bold),
                decoration: InputDecoration(
                  hintText: "Enter IP (Blank for My IP)",
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                  prefixIcon: const Icon(Icons.radar, color: accentPink),
                  suffixIcon: IconButton(
                    icon: Icon(Icons.search, color: isLoading ? Colors.grey : successGreen),
                    onPressed: isLoading ? null : () => _fetchIpDetails(_ipController.text.trim()),
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Loading State
            if (isLoading)
              const Center(child: CircularProgressIndicator(color: accentPink)),

            // Error State
            if (errorMessage != null)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: dangerRed.withOpacity(0.1),
                  border: Border.all(color: dangerRed),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error, color: dangerRed),
                    const SizedBox(width: 12),
                    Text(errorMessage!, style: const TextStyle(color: Colors.white)),
                  ],
                ),
              ),

            // Data Result
            if (ipData != null) ...[
              // Map Visual (Simulasi Koordinat)
              Container(
                height: 180,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentPink.withOpacity(0.2)),
                  image: const DecorationImage(
                    image: AssetImage("assets/images/logo.jpg"), // Placeholder map, bisa ganti image map
                    opacity: 0.2,
                    fit: BoxFit.cover,
                  )
                ),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.location_on, color: dangerRed, size: 40),
                      Text(
                        "${ipData!['lat']}, ${ipData!['lon']}",
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, backgroundColor: Colors.black54),
                      )
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),

              // Detail Cards
              _buildInfoTile("IP ADDRESS", ipData!['query'], Icons.wifi, Colors.blue),
              _buildInfoTile("COUNTRY", "${ipData!['country']} (${ipData!['countryCode']})", Icons.public, Colors.orange),
              _buildInfoTile("REGION / CITY", "${ipData!['regionName']} / ${ipData!['city']}", Icons.location_city, Colors.purple),
              _buildInfoTile("ISP / ORG", "${ipData!['isp']} / ${ipData!['org']}", Icons.router, successGreen),
              _buildInfoTile("TIMEZONE", ipData!['timezone'], Icons.access_time, Colors.pink),
              _buildInfoTile("ZIP CODE", ipData!['zip'], Icons.map, Colors.teal),
            ]
          ],
        ),
      ),
    );
  }

  Widget _buildInfoTile(String label, String value, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDarker,
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: color, width: 4)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 4, offset: const Offset(0, 2))],
      ),
      child: Row(
        children: [
          Icon(icon, color: color.withOpacity(0.8), size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Courier')),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.copy, color: Colors.white.withOpacity(0.3), size: 18),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: value));
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Copied!"), duration: Duration(milliseconds: 500)));
            },
          )
        ],
      ),
    );
  }
}
