import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart'; // UNTUK DOWNLOAD INTERNAL
import 'package:path_provider/path_provider.dart'; // UNTUK SAVE PATH
import 'package:open_filex/open_filex.dart'; // UNTUK INSTALL APK
import 'package:permission_handler/permission_handler.dart'; // UNTUK IZIN
import 'constants.dart';

class FlutterBuildPage extends StatefulWidget {
  const FlutterBuildPage({super.key});

  @override
  State<FlutterBuildPage> createState() => _FlutterBuildPageState();
}

class _FlutterBuildPageState extends State<FlutterBuildPage> {
  // State Variables
  File? _selectedFile;
  String _statusLog = "Waiting for project file...";
  bool _isProcessing = false;
  String? _jobId;
  String? _downloadUrl;
  double _buildProgress = 0.0;
  
  // State Download Internal
  bool _isDownloading = false;
  double _downloadProgress = 0.0;
  String _downloadStatusText = "";
  
  // Scroll Controller untuk Terminal
  final ScrollController _scrollController = ScrollController();
  
  // API Config
  final String _uploadApi = "https://litterbox.catbox.moe/resources/internals/api.php";
  final String _buildApi = "bokep😂";

  // 1. Pick File ZIP
  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
    );

    if (result != null) {
      setState(() {
        _selectedFile = File(result.files.single.path!);
        _statusLog = "File selected: ${result.files.single.name}\nReady to upload.";
        _downloadUrl = null;
        _buildProgress = 0.0;
        _downloadProgress = 0.0;
        _isDownloading = false;
      });
    }
  }

  // 2. Upload to Litterbox (To get URL)
  Future<String?> _uploadToLitterbox(File file) async {
    try {
      setState(() => _statusLog = "Uploading project to temporary server...");
      
      var request = http.MultipartRequest('POST', Uri.parse(_uploadApi));
      request.fields['reqtype'] = 'fileupload';
      request.fields['time'] = '1h'; 
      request.files.add(await http.MultipartFile.fromPath('fileToUpload', file.path));

      var response = await request.send();
      if (response.statusCode == 200) {
        String url = await response.stream.bytesToString();
        return url.trim();
      } else {
        throw "Upload failed: ${response.statusCode}";
      }
    } catch (e) {
      setState(() {
        _statusLog = "Error Uploading: $e";
        _isProcessing = false;
      });
      return null;
    }
  }

  // 3. Trigger Build
  Future<void> _startBuildProcess() async {
    if (_selectedFile == null) return;

    setState(() {
      _isProcessing = true;
      _buildProgress = 0.1;
      _statusLog = "Initializing Upload Process...";
      _downloadUrl = null; // Reset download url
    });

    // Step A: Upload
    String? fileUrl = await _uploadToLitterbox(_selectedFile!);
    if (fileUrl == null) return;

    setState(() {
      _statusLog = "Upload Success: $fileUrl\nTriggering Build Server...";
      _buildProgress = 0.2;
    });

    // Step B: Trigger API Build
    try {
      final response = await http.post(
        Uri.parse(_buildApi),
        headers: {
          'accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "url": fileUrl
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _jobId = data['job_id'];
        setState(() {
          _statusLog = "Job Started! ID: $_jobId\nWaiting for queue...";
          _buildProgress = 0.3;
        });
        
        // Step C: Polling Status
        _monitorBuildStatus();
      } else {
        throw "Build Trigger Failed: ${response.body}";
      }
    } catch (e) {
      setState(() {
        _statusLog = "Error: $e";
        _isProcessing = false;
      });
    }
  }

  // 4. Monitor Status & Update Log Tail
  void _monitorBuildStatus() async {
    if (_jobId == null) return;
    
    bool isBuilding = true;
    while (isBuilding) {
      await Future.delayed(const Duration(seconds: 2));

      try {
        final response = await http.get(
          Uri.parse("$_buildApi/$_jobId"),
          headers: {'accept': 'application/json'},
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          String status = data['status']; 
          String? logTail = data['log_tail']; 

          // Update Log Console
          if (mounted) {
            setState(() {
              if (logTail != null && logTail.isNotEmpty) {
                 _statusLog = logTail; 
                 
                 // Smart Progress Bar
                 if (logTail.contains("Resolving dependencies")) _buildProgress = 0.4;
                 else if (logTail.contains("Downloading packages")) _buildProgress = 0.5;
                 else if (logTail.contains("Running Gradle task")) _buildProgress = 0.7;
                 else if (logTail.contains("assembleRelease")) _buildProgress = 0.9;
              } else {
                 _statusLog = "Status: ${status.toUpperCase()}...\n(Waiting for logs)";
              }
            });

            // Auto Scroll
            if (_scrollController.hasClients) {
              _scrollController.animateTo(
                _scrollController.position.maxScrollExtent,
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOut,
              );
            }
          }

          if (status == 'success') {
            isBuilding = false;
            _finishBuild(true);
          } else if (status == 'failed' || status == 'error') {
            isBuilding = false;
            _finishBuild(false);
          }
        }
      } catch (e) {
        print("Polling error: $e");
      }
    }
  }

  // 5. Finish & Set Download Link
  void _finishBuild(bool success) {
    if (!mounted) return;
    setState(() {
      _isProcessing = false;
      if (success) {
        _buildProgress = 1.0;
        _downloadUrl = "$_buildApi/$_jobId/artifact";
        _statusLog += "\n\n[SUCCESS] Build Finished! APK Ready to download.";
      } else {
        _buildProgress = 0.0;
        _statusLog += "\n\n[FAILED] Build Failed. Please check the logs above.";
      }
    });
    // Scroll pol mentok bawah pas selesai
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
      }
    });
  }

  // ==========================================
  //  NEW: INTERNAL DOWNLOADER LOGIC (NO CHROME)
  // ==========================================
  Future<void> _downloadInternal() async {
    if (_downloadUrl == null) return;

    // 1. Cek Permission Install Packages (Android 8+)
    if (await Permission.requestInstallPackages.isDenied) {
      await Permission.requestInstallPackages.request();
    }
    
    // 2. Siapkan Direktori Penyimpanan
    Directory? dir;
    if (Platform.isAndroid) {
      dir = await getExternalStorageDirectory(); // App-specific folder
    } else {
      dir = await getApplicationDocumentsDirectory();
    }

    if (dir == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Storage error")));
      return;
    }

    String savePath = "${dir.path}/app-release.apk";

    setState(() {
      _isDownloading = true;
      _downloadStatusText = "Downloading...";
    });

    try {
      Dio dio = Dio();
      
      // 3. Proses Download
      await dio.download(
        _downloadUrl!, 
        savePath,
        onReceiveProgress: (received, total) {
          if (total != -1) {
             setState(() {
               _downloadProgress = received / total;
               _downloadStatusText = "${(received / 1024 / 1024).toStringAsFixed(1)} MB / ${(total / 1024 / 1024).toStringAsFixed(1)} MB";
             });
          }
        },
      );

      setState(() {
        _isDownloading = false;
        _downloadStatusText = "Install...";
      });

      // 4. Install APK
      _installApk(savePath);

    } catch (e) {
      setState(() {
        _isDownloading = false;
        _downloadStatusText = "Error!";
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Download Failed: $e")));
    }
  }

  Future<void> _installApk(String filePath) async {
    final result = await OpenFilex.open(filePath);
    if (result.type != ResultType.done) {
       ScaffoldMessenger.of(context).showSnackBar(
         SnackBar(content: Text("Install Failed: ${result.message}"))
       );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text("Flutter Cloud Build", style: TextStyle(fontFamily: 'Orbitron')),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SaturnXBackground(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Info Card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.cyanAccent.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.cloud_upload, color: Colors.cyanAccent, size: 40),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Upload Project (.zip)", 
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          Text("Keep app open during build process.", 
                            style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              
              const SizedBox(height: 20),

              // File Picker Area
              GestureDetector(
                onTap: _isProcessing ? null : _pickFile,
                child: Container(
                  height: 120,
                  decoration: BoxDecoration(
                    color: _selectedFile == null ? Colors.transparent : Colors.cyanAccent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: _selectedFile == null ? Colors.grey : Colors.cyanAccent,
                      width: 2,
                      style: BorderStyle.solid
                    ),
                  ),
                  child: Center(
                    child: _selectedFile == null
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.folder_zip, size: 40, color: Colors.grey[600]),
                            const SizedBox(height: 10),
                            Text("Tap to select ZIP file", style: TextStyle(color: Colors.grey[400])),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.check_circle, size: 40, color: Colors.cyanAccent),
                            const SizedBox(height: 10),
                            Text(_selectedFile!.path.split('/').last, 
                              style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold)),
                          ],
                        ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // BUTTON SECTION
              if (_downloadUrl == null)
                // 1. TOMBOL START BUILD
                ElevatedButton(
                  onPressed: (_selectedFile != null && !_isProcessing) ? _startBuildProcess : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.cyanAccent,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 5,
                    shadowColor: Colors.cyanAccent.withOpacity(0.5)
                  ),
                  child: _isProcessing 
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)),
                          SizedBox(width: 10),
                          Text("BUILDING IN CLOUD...")
                        ],
                      )
                    : const Text("START FLUTTER BUILD", style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                )
              else if (_isDownloading)
                // 2. INDIKATOR DOWNLOAD (INTERNAL)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black45,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.greenAccent)
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Downloading APK...", style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold)),
                          Text(_downloadStatusText, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                        value: _downloadProgress,
                        backgroundColor: Colors.grey[800],
                        color: Colors.greenAccent,
                        minHeight: 10,
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ],
                  ),
                )
              else
                // 3. TOMBOL INSTALL (INTERNAL)
                ElevatedButton.icon(
                  onPressed: _downloadInternal,
                  icon: const Icon(Icons.system_update),
                  label: const Text("INSTALL APK"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF08D9D6), // Hijau Neon
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),

              const SizedBox(height: 20),

              // Console Log Terminal
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0D1117), // Github Dark BG
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.white24),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10)
                    ]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header Terminal
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.terminal, size: 16, color: Colors.greenAccent),
                              const SizedBox(width: 5),
                              const Text("BUILD CONSOLE", style: TextStyle(color: Colors.greenAccent, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                            ],
                          ),
                          if (_isProcessing)
                            Text("${(_buildProgress * 100).toInt()}%", style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const Divider(color: Colors.white12, thickness: 1),
                      
                      // Isi Log (Scrollable)
                      Expanded(
                        child: SingleChildScrollView(
                          controller: _scrollController,
                          child: Text(
                            _statusLog,
                            style: const TextStyle(
                              color: Color(0xFFC9D1D9), 
                              fontFamily: 'Courier', 
                              fontSize: 11,
                              height: 1.4
                            ),
                          ),
                        ),
                      ),
                      
                      // Progress Bar Bawah
                      if (_isProcessing)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: LinearProgressIndicator(
                            value: _buildProgress,
                            backgroundColor: Colors.grey[900],
                            color: Colors.cyanAccent,
                            minHeight: 4,
                          ),
                        )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
