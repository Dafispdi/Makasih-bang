import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart'; // JANGAN LUPA IMPORT INI!
import 'constants.dart';

class TeleBugPage extends StatefulWidget {
  final String sessionKey;

  const TeleBugPage({super.key, required this.sessionKey});

  @override
  State<TeleBugPage> createState() => _TeleBugPageState();
}

class _TeleBugPageState extends State<TeleBugPage> {
  final TextEditingController targetCtrl = TextEditingController();
  final TextEditingController tokenCtrl = TextEditingController();
  bool isLoading = false;

  // --- GANTI CONTROLLER ANIMASI DENGAN VIDEO CONTROLLER ---
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  // Fungsi inisialisasi video biar jalan di background
  void _initializeVideo() {
    _videoController = VideoPlayerController.asset("assets/images/banner.mp4")
      ..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
        });
        _videoController.setLooping(true); // Biar videonya muter terus
        _videoController.setVolume(0.0);   // Jangan berisik, matiin suaranya
        _videoController.play();
      }).catchError((error) {
        debugPrint("Error loading video: $error");
        // Kalau video gagal load, biarkan background hitam polos dari container utama
      });
  }

  @override
  void dispose() {
    _videoController.dispose(); // Hapus video controller biar gak memori leak!
    targetCtrl.dispose();
    tokenCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendAttack() async {
    if (targetCtrl.text.isEmpty || tokenCtrl.text.isEmpty) {
      _showSnack("Isi Target dan Token Bot dulu!", Colors.red);
      return;
    }
    // ... (Logika send attack sama seperti sebelumnya, gak usah kuubah)
    setState(() => isLoading = true);
    String url = "$baseUrl/api/tele-bug?target=${targetCtrl.text}&botToken=${tokenCtrl.text}&key=${widget.sessionKey}";
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        _showSnack("🚀 Attack Launched Successfully!", Colors.green);
      } else {
        _showSnack("❌ Failed: ${response.body}", Colors.red);
      }
    } catch (e) {
      _showSnack("❌ Error Connection: $e", Colors.red);
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: TextStyle(fontFamily: 'Orbitron')),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark, 
      resizeToAvoidBottomInset: false, // Biar keyboard gak ngerusak layout video
      body: Stack(
        children: [
          // 1. Layer Paling Belakang: VIDEO
          _buildVideoBackground(),
          
          // 2. Layer Overlay Gelap (Biar teks kebaca)
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.4),
                  primaryDark.withOpacity(0.8),
                ],
              ),
            ),
          ),

          // 3. Layer Konten (Form dll)
          SafeArea(
            child: Center( // Center biar konten di tengah
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 40),
                    _buildFormCard(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoBackground() {
    if (!_isVideoInitialized) {
      return Container(color: primaryDark); // Placeholder loading
    }
    // Trik biar video menutupi seluruh layar (Cover fit)
    return SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _videoController.value.size.width,
          height: _videoController.value.size.height,
          child: VideoPlayer(_videoController),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    // Kutambah sedikit efek shadow di teks biar lebih pop-up di atas video
    return Column(
      children: [
        Icon(Icons.telegram, size: 50, color: accentPink),
        SizedBox(height: 10),
        Text(
          "TELEGRAM BUG SYSTEM",
          textAlign: TextAlign.center,
          style: TextStyle(
            color: primaryWhite,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            shadows: [
              Shadow(blurRadius: 10, color: accentPink, offset: Offset(0,0))
            ]
          ),
        ),
        Text(
          "SaturnX Apps New Era",
          style: TextStyle(color: lightPink.withOpacity(0.8), fontSize: 14, letterSpacing: 1.2),
        ),
      ],
    );
  }

  Widget _buildFormCard() {
    // Kubuat cardnya lebih "Cyberpunk" dengan border yang lebih tegas dan glow
    return ClipRRect(
      borderRadius: BorderRadius.circular(25),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.5), // Lebih gelap biar kontras sama video
            borderRadius: BorderRadius.circular(25),
            border: Border.all(color: accentPink.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(color: accentPink.withOpacity(0.2), blurRadius: 30, spreadRadius: 1),
            ],
          ),
          child: Column(
            children: [
              _buildInput(targetCtrl, "Target ID", Icons.person_pin),
              const SizedBox(height: 20),
              _buildInput(tokenCtrl, "Bot Token", Icons.vpn_key),
              const SizedBox(height: 40),
              
              GestureDetector(
                onTap: isLoading ? null : _sendAttack,
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 300),
                  width: double.infinity,
                  height: 60,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: isLoading 
                        ? [Colors.grey.shade800, Colors.grey.shade900] 
                        : [primaryPink, accentPink],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: isLoading ? [] : [
                      BoxShadow(
                        color: accentPink.withOpacity(0.6),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Center(
                    child: isLoading
                        ? CircularProgressIndicator(color: Colors.white)
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.rocket_launch, color: Colors.white),
                              SizedBox(width: 12),
                              Text(
                                "LAUNCH ATTACK",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1.5
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInput(TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      cursorColor: accentPink,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: lightPink.withOpacity(0.7)),
        prefixIcon: Icon(icon, color: accentPink),
        filled: true,
        fillColor: Colors.white.withOpacity(0.05),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: accentPink, width: 2),
        ),
      ),
    );
  }
}
