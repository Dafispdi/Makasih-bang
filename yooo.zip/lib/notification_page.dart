import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'constants.dart';
import 'dart:ui'; // Diperlukan untuk ImageFilter (Blur effect)

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  List<dynamic> notifications = [];
  bool isLoading = true;
  final GlobalKey<RefreshIndicatorState> _refreshKey = GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    super.initState();
    fetchNotifications();
  }

  Future<void> fetchNotifications() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/api/notifications'));
      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        
        if (mounted) {
          setState(() {
            notifications = data;
            isLoading = false;
          });
        }

        // LOGIC TITIK MERAH: Simpan ID notifikasi terbaru
        if (data.isNotEmpty) {
          final latestId = data[0]['id'].toString();
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('last_seen_notif_id', latestId);
        }
      }
    } catch (e) {
      print("Error fetching notifs: $e");
      if (mounted) setState(() => isLoading = false);
    }
  }

  Color _getTypeColor(String type) {
    switch (type) {
      case 'warning': return warningOrange;
      case 'success': return successGreen;
      case 'danger': return dangerRed;
      case 'info':
      default: return accentPink; // Ungu Lembayung Default
    }
  }

  IconData _getTypeIcon(String type) {
    switch (type) {
      case 'warning': return Icons.warning_amber_rounded;
      case 'success': return Icons.check_circle_outline;
      case 'danger': return Icons.dangerous_outlined;
      case 'info':
      default: return Icons.notifications_active_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      extendBodyBehindAppBar: true, // Agar blur effect AppBar kena background
      appBar: AppBar(
        title: Text(
          "SYSTEM LOGS", 
          style: TextStyle(
            color: Colors.white, 
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 2.0,
            shadows: [
              Shadow(color: accentPink, blurRadius: 10),
            ]
          )
        ),
        centerTitle: true,
        backgroundColor: primaryDark.withOpacity(0.7),
        elevation: 0,
        flexibleSpace: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(color: Colors.transparent),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SaturnXBackground(
        child: isLoading
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircularProgressIndicator(color: accentPink),
                    const SizedBox(height: 15),
                    Text("DECRYPTING DATA...", style: TextStyle(color: accentPink.withOpacity(0.7), fontFamily: 'Orbitron'))
                  ],
                )
              )
            : notifications.isEmpty
                ? _buildEmptyState()
                : RefreshIndicator(
                    key: _refreshKey,
                    onRefresh: fetchNotifications,
                    color: accentPink,
                    backgroundColor: cardDarker,
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 110, 16, 20), // Top padding buat AppBar
                      itemCount: notifications.length,
                      itemBuilder: (context, index) {
                        final item = notifications[index];
                        // Animasi delay per item
                        return TweenAnimationBuilder<double>(
                          tween: Tween(begin: 0, end: 1),
                          duration: Duration(milliseconds: 400 + (index * 100)),
                          curve: Curves.easeOutQuint,
                          builder: (context, value, child) {
                            return Transform.translate(
                              offset: Offset(0, 50 * (1 - value)), // Slide Up Effect
                              child: Opacity(
                                opacity: value,
                                child: _buildCyberCard(item),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: cardDark.withOpacity(0.5),
              boxShadow: [
                BoxShadow(color: accentPink.withOpacity(0.2), blurRadius: 50, spreadRadius: 10)
              ]
            ),
            child: Icon(Icons.radar, size: 80, color: Colors.white24),
          ),
          const SizedBox(height: 25),
          const Text(
            "NO SIGNAL DETECTED",
            style: TextStyle(
              color: Colors.white70, 
              fontFamily: 'Orbitron', 
              fontSize: 18, 
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5
            )
          ),
          const SizedBox(height: 10),
          Text(
            "System is currently silent.\nCheck back later for updates.",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildCyberCard(Map<String, dynamic> item) {
    final color = _getTypeColor(item['type'] ?? 'info');
    final date = item['date']?.split(',')[0] ?? '';
    final time = item['date']?.split(',')[1] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Stack(
        children: [
          // 1. Glow Effect di belakang kartu
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.15), // Glow warna sesuai tipe
                    blurRadius: 20,
                    spreadRadius: -5,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
            ),
          ),

          // 2. Kartu Utama
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5), // Glass Effect
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  // Gradient Ungu Lembayung Gelap
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      cardDark.withOpacity(0.9),
                      const Color(0xFF150520).withOpacity(0.95), // Lebih gelap di bawah
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: color.withOpacity(0.3), // Border tipis sesuai tipe
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Bar
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Icon Box
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: color.withOpacity(0.3)),
                            boxShadow: [
                              BoxShadow(color: color.withOpacity(0.2), blurRadius: 10)
                            ]
                          ),
                          child: Icon(_getTypeIcon(item['type']), color: color, size: 22),
                        ),
                        const SizedBox(width: 14),
                        
                        // Title & Time
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item['title'] ?? 'ENCRYPTED MESSAGE',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron', // Font Tech
                                  letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Icon(Icons.access_time, size: 10, color: accentGrey),
                                  const SizedBox(width: 4),
                                  Text(
                                    "$date • $time",
                                    style: TextStyle(color: accentGrey, fontSize: 11),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Divider(color: Colors.white10, height: 1),
                    ),

                    // Message Content
                    Text(
                      item['message'] ?? '',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 13,
                        height: 1.5,
                        fontFamily: 'Roboto', // Font baca yang nyaman
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Footer: Creator & Badge
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Status Badge
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.white12),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            item['type']?.toString().toUpperCase() ?? "INFO",
                            style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold),
                          ),
                        ),

                        // Creator
                        Row(
                          children: [
                            Text(
                              "SENDER: ",
                              style: TextStyle(color: Colors.white38, fontSize: 10),
                            ),
                            Text(
                              "${item['creator'] ?? 'SYSTEM'}",
                              style: const TextStyle(color: accentPink, fontSize: 10, fontWeight: FontWeight.bold),
                            ),
                          ],
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),

          // 3. Dekorasi Tech (Garis di pojok kanan atas)
          Positioned(
            top: 0,
            right: 0,
            child: Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(color: color, width: 2),
                  right: BorderSide(color: color, width: 2),
                ),
                borderRadius: const BorderRadius.only(topRight: Radius.circular(16)),
              ),
            ),
          ),
          // Dekorasi Tech (Garis di pojok kiri bawah)
          Positioned(
            bottom: 0,
            left: 0,
            child: Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: color.withOpacity(0.5), width: 2),
                  left: BorderSide(color: color.withOpacity(0.5), width: 2),
                ),
                borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(16)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
