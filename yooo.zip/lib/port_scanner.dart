import 'dart:async';
import 'package:flutter/material.dart';
import 'constants.dart';

class PortScannerPage extends StatefulWidget {
  const PortScannerPage({super.key});

  @override
  State<PortScannerPage> createState() => _PortScannerPageState();
}

class _PortScannerPageState extends State<PortScannerPage> {
  final TextEditingController _ipController = TextEditingController(text: "152.53.249.119");
  List<String> consoleLogs = [];
  bool isScanning = false;
  final ScrollController _scrollController = ScrollController();

  final List<int> commonPorts = [21, 22, 23, 25, 53, 80, 110, 443, 3306, 8080];

  void _startPortScan() async {
    setState(() {
      isScanning = true;
      consoleLogs.clear();
      consoleLogs.add("[*] Starting Port Scan on ${_ipController.text}...");
    });

    for (var port in commonPorts) {
      if (!mounted) break;
      await Future.delayed(const Duration(milliseconds: 500)); // Simulasi delay network
      
      bool isOpen = [22, 80, 443, 8080].contains(port); // Simulasi port yang terbuka
      
      setState(() {
        if (isOpen) {
          consoleLogs.add("[+] Port $port \t: OPEN (SERVICE FOUND)");
        } else {
          consoleLogs.add("[-] Port $port \t: CLOSED");
        }
      });
      _scrollToBottom();
    }

    setState(() {
      isScanning = false;
      consoleLogs.add("[*] Scan Completed.");
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        title: const Text("Port Scanner", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Input Section
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: cardDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentPink.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _ipController,
                style: const TextStyle(color: Colors.white, fontFamily: 'Courier'),
                decoration: InputDecoration(
                  hintText: "Enter Target IP / Domain",
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                  border: InputBorder.none,
                  prefixIcon: const Icon(Icons.gps_fixed, color: accentPink),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  suffixIcon: IconButton(
                    icon: Icon(isScanning ? Icons.stop_circle : Icons.play_circle, color: isScanning ? dangerRed : successGreen, size: 30),
                    onPressed: isScanning ? null : _startPortScan,
                  ),
                ),
              ),
            ),
            
            const SizedBox(height: 20),

            // Console Output
            Expanded(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, spreadRadius: 2),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.terminal, color: Colors.white70, size: 16),
                        const SizedBox(width: 8),
                        const Text("TERMINAL OUTPUT", style: TextStyle(color: Colors.white70, fontSize: 10, letterSpacing: 1.5, fontFamily: 'Orbitron')),
                      ],
                    ),
                    const Divider(color: Colors.white12),
                    Expanded(
                      child: ListView.builder(
                        controller: _scrollController,
                        itemCount: consoleLogs.length,
                        itemBuilder: (context, index) {
                          final log = consoleLogs[index];
                          Color logColor = Colors.white;
                          if (log.startsWith("[+]")) logColor = successGreen;
                          if (log.startsWith("[-]")) logColor = dangerRed;
                          if (log.startsWith("[*]")) logColor = warningOrange;

                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Text(
                              log,
                              style: TextStyle(
                                color: logColor,
                                fontFamily: 'Courier',
                                fontSize: 13,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
