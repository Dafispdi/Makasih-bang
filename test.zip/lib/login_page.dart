import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'splash.dart';
import 'constants.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;
  bool _isVideoInitialized = false;

  late AnimationController _slideController;
  late Animation<Offset> _slideAnim;
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initVideoBackground();
    initLogin();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _videoController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  void _initAnimations() {
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));
  }

    void _initVideoBackground() {
  _videoController = VideoPlayerController.asset(
    "assets/videos/intro.mp4",
    // PERBAIKAN: videoPlayerOptions harus di dalam kurung asset(...)
    videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true), 
  )..initialize().then((_) {
      setState(() {
        _isVideoInitialized = true;
      });
      _videoController.setLooping(true);
      _videoController.setVolume(0);
      _videoController.play();
    });
}

  Future<void> initLogin() async {
    androidId = await getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          if (mounted) _navigateToSplash(savedUser, savedPass, data);
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    try {
      final android = await deviceInfo.androidInfo;
      return android.id ?? "unknown_device";
    } catch (e) {
       return "unknown_device_error";
    }
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      ).timeout(const Duration(seconds: 15));

      if (validate.statusCode != 200) throw Exception('Server Error');

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "⏳ Access Expired",
          message: "Your access license has expired.",
          color: warningOrange,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showPopup(
          title: "❌ Authentication Failed",
          message: "Invalid credentials.",
          color: dangerRed,
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) _navigateToSplash(username, password, validData);
      }
    } catch (e) {
      _showPopup(
        title: "⚠️ Connection Error",
        message: "Failed to connect to server.",
        color: warningOrange,
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  void _navigateToSplash(String user, String pass, Map<String, dynamic> data) {
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => SplashScreen(
          username: user,
          password: pass,
          role: data['role'] ?? 'User',
          sessionKey: data['key'] ?? '',
          expiredDate: data['expiredDate'] ?? '',
          listBug: (data['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          listDoos: (data['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          news: (data['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
        ),
        transitionsBuilder: (_, animation, __, child) => FadeTransition(opacity: animation, child: child),
        transitionDuration: const Duration(milliseconds: 500)
      ),
    );
  }

  void _showPopup({required String title, required String message, Color color = accentPink, bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDarker,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: color.withOpacity(0.3), width: 1)),
        title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        content: Text(message, style: const TextStyle(color: Colors.white70)),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () => launchUrl(Uri.parse("https://t.me/Kyxsancs"), mode: LaunchMode.externalApplication),
              child: const Text("Contact Admin", style: TextStyle(color: accentPink)),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close", style: TextStyle(color: color.withOpacity(0.8))),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      resizeToAvoidBottomInset: false,
      body: Stack(
        fit: StackFit.expand, // FIX: Penting agar stack full screen
        children: [
          // 1. VIDEO BACKGROUND FULL SCREEN (intro.mp4)
          if (_isVideoInitialized)
            SizedBox.expand( // FIX: Paksa ukuran full
              child: FittedBox(
                fit: BoxFit.cover, // FIX: Crop agar tidak ada bar hitam
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            ),

          // 2. OVERLAY HITAM TRANSPARAN
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  primaryDark.withOpacity(0.4),
                  primaryDark.withOpacity(0.7),
                  primaryDark.withOpacity(0.9),
                ],
              ),
            ),
          ),

          // 3. KONTEN FORM
          Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.only(
                left: 24, right: 24, top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24
              ),
              child: SlideTransition(
                position: _slideAnim,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 40),
                    _buildGlassFormCard(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Hero(
          tag: 'logo',
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                 BoxShadow(color: accentPink.withOpacity(0.3), blurRadius: 25, spreadRadius: 5)
              ]
            ),
            child: CircleAvatar(
              radius: 50,
              backgroundColor: Colors.transparent,
              backgroundImage: const AssetImage('assets/images/logo.jpg'),
              onBackgroundImageError: (_, __) => const Icon(Icons.error, color: dangerRed),
            ),
          ),
        ),
        const SizedBox(height: 25),
        Text(
          "SATURNX SYSTEM",
          style: TextStyle(
            fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white,
            letterSpacing: 3.0,
            shadows: [Shadow(color: accentPink.withOpacity(0.8), blurRadius: 15)],
            fontFamily: 'Montserrat',
          ),
        ),
        const SizedBox(height: 8),
         Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: accentPink.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: accentPink.withOpacity(0.3))
          ),
          child: const Text("SECURE ACCESS SERVEE", style: TextStyle(color: accentPink, fontSize: 12)),
        ),
      ],
    );
  }

  Widget _buildGlassFormCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            color: cardDarker.withOpacity(0.5),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: accentPink.withOpacity(0.2), width: 1.5),
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text("AUTHENTICATION REQUIRED", textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.9), fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                const SizedBox(height: 25),
                _buildNeonInput(controller: userController, label: "Username", icon: Icons.person_outline_rounded),
                const SizedBox(height: 20),
                _buildNeonInput(controller: passController, label: "Password", icon: Icons.lock_outline_rounded, isPassword: true),
                const SizedBox(height: 35),
                _buildNeonButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNeonInput({required TextEditingController controller, required String label, required IconData icon, bool isPassword = false}) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword ? _obscurePassword : false,
      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
      cursorColor: accentPink,
      validator: (value) => value!.isEmpty ? "$label cannot be empty" : null,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: accentGrey.withOpacity(0.8)),
        prefixIcon: Icon(icon, color: accentPink.withOpacity(0.7)),
        suffixIcon: isPassword ? IconButton(icon: Icon(_obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined, color: accentGrey), onPressed: () => setState(() => _obscurePassword = !_obscurePassword)) : null,
        filled: true,
        fillColor: Colors.black.withOpacity(0.3),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: accentPink.withOpacity(0.1))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: accentPink, width: 2)),
      ),
    );
  }

  Widget _buildNeonButton() {
    return Container(
      height: 55,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: primaryPink.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 5))],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : login,
        style: ElevatedButton.styleFrom(backgroundColor: primaryPink, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        child: isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text("CONTINUED", style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }
}
