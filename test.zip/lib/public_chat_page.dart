import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'constants.dart'; // Pastikan file ini ada

class PublicChatPage extends StatefulWidget {
  final String username;
  final String role; // Untuk badge role (Owner, Admin/Reseller, Member)

  const PublicChatPage({
    super.key,
    required this.username,
    required this.role,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final String _databaseUrl = "https://apps-saturnx-default-rtdb.asia-southeast1.firebasedatabase.app";

  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  
  List<Map<String, dynamic>> _messages = [];
  bool _isLoading = true;
  Timer? _refreshTimer;
  DateTime? _lastMessageTime; 

  @override
  void initState() {
    super.initState();
    _fetchMessages();
    // Auto refresh setiap 2 detik
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (mounted) _fetchMessages(silent: true);
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _msgController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // --- FUNGSI AMBIL PESAN ---
  Future<void> _fetchMessages({bool silent = false}) async {
    if (!silent) setState(() => _isLoading = true);

    try {
      final response = await http.get(Uri.parse("$_databaseUrl/messages.json"));

      if (response.statusCode == 200 && response.body != "null") {
        final Map<String, dynamic> data = jsonDecode(response.body);
        final List<Map<String, dynamic>> loadedMessages = [];

        data.forEach((key, value) {
          loadedMessages.add({
            'id': key,
            'username': value['username'] ?? 'Anon',
            'message': value['message'] ?? '',
            'role': value['role'] ?? 'member',
            'timestamp': value['timestamp'] ?? 0,
          });
        });

        // Sorting manual by timestamp
        loadedMessages.sort((a, b) => a['timestamp'].compareTo(b['timestamp']));

        if (mounted) {
          setState(() {
            _messages = loadedMessages;
            _isLoading = false;
          });
          if (!silent) _scrollToBottom();
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      print("Error Fetching: $e");
      if (mounted && !silent) setState(() => _isLoading = false);
    }
  }

  // --- FUNGSI KIRIM PESAN (DENGAN ANTI-SPAM) ---
  Future<void> _sendMessage() async {
    final text = _msgController.text.trim();
    if (text.isEmpty) return;

    // --- FITUR ANTI-SPAM ---
    final now = DateTime.now();
    if (_lastMessageTime != null) {
      final difference = now.difference(_lastMessageTime!);
      if (difference.inSeconds < 5) { // Cooldown 3 detik
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text("Tunggu 5 detik sebelum kirim lagi!"),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom + 10,
              left: 20,
              right: 20,
            ),
          ),
        );
        return; 
      }
    }

    _msgController.clear();
    _lastMessageTime = now; 

    try {
      final newMessage = {
        'username': widget.username,
        'message': text,
        'role': widget.role,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      await http.post(
        Uri.parse("$_databaseUrl/messages.json"),
        body: jsonEncode(newMessage),
      );

      _fetchMessages(silent: true);
      _scrollToBottom();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to send message"), backgroundColor: Colors.red),
      );
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // --- LOGIC BUILDER BUBBLE CHAT ---
  Widget _buildMessageBubble(Map<String, dynamic> msg, bool isMe) {
    final date = DateTime.fromMillisecondsSinceEpoch(msg['timestamp']);
    final timeStr = "${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}";

    Color roleColor = Colors.grey;
    if (msg['role'] == 'owner') roleColor = dangerRed; // Merah
    if (msg['role'] == 'vip') roleColor = warningOrange; // Orange
    if (msg['role'] == 'reseller') roleColor = successGreen; // Hijau

    // Cek apakah pesan ini me-mention username kita
    bool isMentioningMe = msg['message'].toString().contains("@${widget.username}");
    
    // Warna bubble & border berubah kalau di-tag
    Color bubbleColor = isMe 
        ? accentPink.withOpacity(0.2) 
        : (isMentioningMe ? accentPink.withOpacity(0.4) : cardDark); 
        
    Color borderColor = isMe 
        ? accentPink.withOpacity(0.5) 
        : (isMentioningMe ? warningOrange : Colors.white.withOpacity(0.1));

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isMe)
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    InkWell(
                      onTap: () {
                        // Fitur Klik Nama -> Auto Tag
                        String currentText = _msgController.text;
                        String tagText = "@${msg['username']} ";
                        setState(() {
                          _msgController.text = currentText + tagText;
                          _msgController.selection = TextSelection.fromPosition(
                            TextPosition(offset: _msgController.text.length)
                          );
                        });
                      },
                      child: Text(
                        msg['username'],
                        style: TextStyle(color: roleColor, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ),
                    if (msg['role'] == 'owner' || msg['role'] == 'reseller') ...[
                      const SizedBox(width: 4),
                      Icon(Icons.verified, color: roleColor, size: 12),
                    ]
                  ],
                ),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: bubbleColor,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isMe ? 16 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 16),
                ),
                border: Border.all(
                  color: borderColor,
                  width: isMentioningMe ? 1.5 : 1,
                ),
                boxShadow: isMentioningMe ? [
                  BoxShadow(color: warningOrange.withOpacity(0.2), blurRadius: 8, spreadRadius: 1)
                ] : [],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    msg['message'],
                    style: TextStyle(
                      color: Colors.white, 
                      fontSize: 14,
                      fontWeight: isMentioningMe ? FontWeight.w600 : FontWeight.normal
                    ),
                  ),
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      timeStr,
                      style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: cardDarker,
        elevation: 0,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentPink.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: accentPink.withOpacity(0.5)),
              ),
              child: const Icon(Icons.public, color: accentPink, size: 18),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("PUBLIC SATURNX", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.bold)),
                Row(
                  children: [
                    Container(width: 6, height: 6, decoration: const BoxDecoration(color: successGreen, shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    const Text("Live Connection", style: TextStyle(color: successGreen, fontSize: 10)),
                  ],
                )
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white54),
            onPressed: () => _fetchMessages(),
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: accentPink))
                : _messages.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.chat_bubble_outline, size: 60, color: Colors.white.withOpacity(0.1)),
                            const SizedBox(height: 16),
                            Text("No messages yet.\nStart the conversation!", textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.3))),
                          ],
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.all(16),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final msg = _messages[index];
                          final isMe = msg['username'] == widget.username;
                          return _buildMessageBubble(msg, isMe);
                        },
                      ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: cardDarker,
              border: Border(top: BorderSide(color: Colors.white.withOpacity(0.05))),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: primaryDark,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: accentPink.withOpacity(0.3)),
                    ),
                    child: TextField(
                      controller: _msgController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: "Type encoded message...",
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                      ),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: _sendMessage,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [primaryPink, accentPink]),
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: accentPink.withOpacity(0.4), blurRadius: 10)],
                    ),
                    child: const Icon(Icons.send, color: Colors.white, size: 20),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
