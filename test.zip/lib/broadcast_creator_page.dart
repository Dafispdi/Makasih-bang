import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'constants.dart';

class BroadcastCreatorPage extends StatefulWidget {
  final String sessionKey;
  const BroadcastCreatorPage({super.key, required this.sessionKey});

  @override
  State<BroadcastCreatorPage> createState() => _BroadcastCreatorPageState();
}

class _BroadcastCreatorPageState extends State<BroadcastCreatorPage> {
  final _titleController = TextEditingController();
  final _msgController = TextEditingController();
  String _selectedType = 'info';
  bool _isLoading = false;

  final List<Map<String, dynamic>> _types = [
    {'value': 'info', 'label': 'Informasi', 'color': accentPink, 'icon': Icons.info},
    {'value': 'success', 'label': 'Sukses / Update', 'color': successGreen, 'icon': Icons.check_circle},
    {'value': 'warning', 'label': 'Peringatan', 'color': warningOrange, 'icon': Icons.warning},
    {'value': 'danger', 'label': 'Bahaya / Maintenance', 'color': dangerRed, 'icon': Icons.error},
  ];

  Future<void> _sendBroadcast() async {
    if (_titleController.text.isEmpty || _msgController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Judul dan Pesan tidak boleh kosong!")),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/notifications/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "key": widget.sessionKey,
          "title": _titleController.text,
          "message": _msgController.text,
          "type": _selectedType
        }),
      );

      final data = jsonDecode(response.body);

      if (data['success'] == true) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(backgroundColor: successGreen, content: Text("✅ ${data['message']}")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(backgroundColor: dangerRed, content: Text("❌ ${data['message']}")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: dangerRed, content: Text("Error: $e")),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text("Buat Broadcast", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SaturnXBackground(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildInputLabel("Judul Notifikasi"),
              _buildTextField(_titleController, "Contoh: Maintenance Server", Icons.title),
              const SizedBox(height: 20),
              
              _buildInputLabel("Tipe Pesan"),
              _buildTypeSelector(),
              const SizedBox(height: 20),
              
              _buildInputLabel("Isi Pesan"),
              _buildTextField(_msgController, "Tulis pesan broadcast disini...", Icons.message, maxLines: 5),
              const SizedBox(height: 30),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isLoading ? null : _sendBroadcast,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentPink,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: _isLoading 
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.send, color: Colors.white),
                  label: Text(
                    _isLoading ? "Mengirim..." : "KIRIM BROADCAST",
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {int maxLines = 1}) {
    return Container(
      decoration: BoxDecoration(
        color: cardDarker,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.white24),
          prefixIcon: Icon(icon, color: accentPink),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(16),
        ),
      ),
    );
  }

  Widget _buildTypeSelector() {
    return SizedBox(
      height: 60,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: _types.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final type = _types[index];
          final isSelected = _selectedType == type['value'];
          final color = type['color'] as Color;

          return GestureDetector(
            onTap: () => setState(() => _selectedType = type['value']),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? color.withOpacity(0.2) : cardDarker,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected ? color : Colors.white10,
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: Row(
                children: [
                  Icon(type['icon'], color: isSelected ? color : Colors.white54, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    type['label'],
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.white54,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
