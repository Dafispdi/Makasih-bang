import 'package:flutter/material.dart';
import 'dart:ui';

// --- TEMA SATURNX: LEMBAYUNG GLASS (IRIDESCENT VIOLET) ---
const String baseUrl = "http://privserv.my.id:2410"; 

const Color primaryDark = Color(0xFF090415);   // Background sangat gelap ungu kehitaman
const Color deepSpace = Color(0xFF16082B);     // Ungu pekat untuk bayangan

// Accent: Ungu Lembayung (Iridescent)
const Color accentPink = Color(0xFFD946EF);    // Lembayung Pink/Purple Terang
const Color primaryPink = Color(0xFF8B5CF6);   // Violet Solid
const Color lightPink = Color(0xFFF0ABFC);     // Highlight terang
const Color cyanIridescent = Color(0xFF22D3EE); // Cyan untuk efek bias/hologram

// Warna Status (Disesuaikan agar blend dengan ungu)
const Color dangerRed = Color(0xFFFB7185);     
const Color successGreen = Color(0xFF34D399);  
const Color warningOrange = Color(0xFFFBBF24); 

// Utilitas
const Color primaryWhite = Colors.white;
const Color glassColor = Colors.white10;

// ========================================================
// REUSABLE WIDGETS UNTUK EFEK ELEGAN GLASSMORPHISM
// ========================================================

// 1. Background Lembayung Kaca
class SaturnXBackground extends StatelessWidget {
  final Widget child;
  const SaturnXBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Warna dasar gelap
        Container(color: primaryDark),
        
        // Orb Kiri Atas (Ungu)
        Positioned(
          top: -100,
          left: -100,
          child: Container(
            width: 300,
            height: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: primaryPink.withOpacity(0.15),
              boxShadow: [BoxShadow(color: primaryPink.withOpacity(0.2), blurRadius: 100)],
            ),
          ),
        ),
        
        // Orb Kanan Bawah (Cyan Lembayung)
        Positioned(
          bottom: -150,
          right: -50,
          child: Container(
            width: 350,
            height: 350,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: cyanIridescent.withOpacity(0.1),
              boxShadow: [BoxShadow(color: cyanIridescent.withOpacity(0.2), blurRadius: 100)],
            ),
          ),
        ),
        
        // Efek Blur Menyeluruh
        Positioned.fill(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
            child: Container(color: Colors.transparent),
          ),
        ),
        
        // Konten Halaman
        child,
      ],
    );
  }
}

// 2. Card Kaca Elegan (Gunakan ini pengganti cardDark/cardDarker)
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final double opacityLevel;

  const GlassCard({
    super.key, 
    required this.child, 
    this.padding, 
    this.margin, 
    this.borderRadius = 20,
    this.opacityLevel = 0.08
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(color: Colors.white.withOpacity(0.15), width: 1.2),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(opacityLevel + 0.05),
            Colors.white.withOpacity(opacityLevel),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 30,
            spreadRadius: -5,
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Padding(
            padding: padding ?? const EdgeInsets.all(20),
            child: child,
          ),
        ),
      ),
    );
  }
}
