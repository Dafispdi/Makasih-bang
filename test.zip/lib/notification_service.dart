import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/widgets.dart';
// Ganti dengan path yang sesuai ke notification_page.dart kamu
import 'notification_page.dart'; 

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  // Kita butuh GlobalKey ini untuk navigasi tanpa BuildContext
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static Future<void> init() async {
    // 1. Setup Android
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    // 2. Gabungkan Setting
    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    // 3. Initialize dengan Handler tap
    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        // Logika ketika notif diklik
        if (response.payload == 'go_to_notif_page') {
          // Navigasi ke Halaman Notifikasi
          navigatorKey.currentState?.push(
            MaterialPageRoute(builder: (_) => const NotificationPage())
          );
        }
      },
    );

    // 4. Request Permission (Android 13+)
    await _notificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    required String type,
  }) async {
    // Styling Judul
    String emoTitle = title;
    if (type == 'danger') emoTitle = "‼️ SYSTEM ALERT: $title";
    else if (type == 'warning') emoTitle = "⚠️ WARNING: $title";
    else if (type == 'success') emoTitle = "✅ SUCCESS: $title";
    else emoTitle = "🟣 SATURNX INFO: $title";

    await _notificationsPlugin.show(
      id,
      emoTitle,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          'saturnx_channel_id',
          'SaturnX Broadcast',
          channelDescription: 'Notifikasi sistem SaturnX',
          importance: Importance.max,
          priority: Priority.high,
          color: const Color(0xFFCF3FFF), // Ungu Lembayung
          ledColor: const Color(0xFFCF3FFF),
          ledOnMs: 1000,
          ledOffMs: 500,
          enableLights: true,
          playSound: true,
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
      payload: 'go_to_notif_page', // Payload ini kunci agar handler tau harus kemana
    );
  }
}
