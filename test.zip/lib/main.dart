import 'package:flutter/material.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'landing.dart';
import 'constants.dart';
import 'global_player.dart'; 
// 👇 1. TAMBAHKAN IMPORT INI
import 'notification_service.dart'; 

void main() async { // 👈 2. UBAH JADI ASYNC
  // 👇 3. TAMBAHKAN DUA BARIS INI
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init(); 

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // 👇 4. MASUKKAN KEY INI (PENTING BANGET!)
      navigatorKey: NotificationService.navigatorKey, 
      
      debugShowCheckedModeBanner: false,
      title: 'SaturnX Apps',
      
      // Setup Tema
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: const Color(0xFF0F0518),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB027F6),
          brightness: Brightness.dark,
          primary: const Color(0xFFB027F6),
          secondary: const Color(0xFF5D1285),
        ),
        useMaterial3: true,
      ),

      // Global Player Overlay (JANGAN DIHAPUS)
      builder: (context, child) {
        return GlobalPlayerOverlay(child: child!);
      },
      
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const LandingPage());
          
          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/dashboard':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
            );

          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );

          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => SellerPage(
                keyToken: args['keyToken'],
                userRole: args['userRole'] ?? 'member',
              ),
            );

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(
                sessionKey: args['sessionKey'],
              ),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text("404 - Not Found")),
              ),
            );
        }
      },
    );
  }
}
